# To change this template, choose Tools | Templates
# and open the template in the editor.

__author__="Klaas Cuvelier (http://cuvedev.net, cuvelierklaas@gmail.com"
__date__ ="$Apr 5, 2010 11:30:22 AM$"

class Expression file is undefined on line 11, column 9 in Templates/Python/_module.py.:

	def __init__(self):
		return
