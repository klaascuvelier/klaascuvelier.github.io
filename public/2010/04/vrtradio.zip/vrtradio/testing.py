import vrtplayer


print 'start'
vrtplayer.addStations()
print 'end'