'''
Author		: Klaas Cuvelier, cuvelierklaas@gmail.com, http://www.cuvedev.net
Date		: 05 apr 2010
Disclaimer	: I'm not responsible for ANYthing!
Info		: I wrote this app so I would be able to listen to Flemish radio
			  stations without needing the have an FM tuner
'''

import mc, xbmc

# station info
stations = {}
stations['radio1']			= {'title': 'Radio 1', 'logo': 'radio1.jpg', 'url': 'http://mp3.streampower.be/radio1'}
stations['radio1classics']	= {'title': 'Radio 1 Classics', 'logo': 'radio1.jpg', 'url': 'http://mp3.streampower.be/radio1_classics'}
stations['radio2ant']		= {'title': 'Radio 2 Antwerpen', 'logo': 'radio2.jpg', 'url': 'http://mp3.streampower.be/ra2ant'}
stations['radio2vlb']		= {'title': 'Radio 2 Vlaams Brabant', 'logo': 'radio2.jpg', 'url': 'http://mp3.streampower.be/ra2vlb'}
stations['radio2lim']		= {'title': 'Radio 2 Limburg', 'logo': 'radio2.jpg', 'url': 'http://mp3.streampower.be/ra2lim'}
stations['radio2ovl']		= {'title': 'Radio 2 Oost-Vlaanderen', 'logo': 'radio2.jpg', 'url': 'http://mp3.streampower.be/ra2ovl'}
stations['radio2wvl']		= {'title': 'Radio 2 West-Vlaanderen', 'logo': 'radio2.jpg', 'url': 'http://mp3.streampower.be/ra2wvl'}
stations['radio2txl']		= {'title': 'Radio 2 De Topcollectie XL', 'logo': 'radio2.jpg', 'url': 'http://mp3.streampower.be/radio2_de_topcollectie_xl'}
stations['klara']			= {'title': 'Radio Klara', 'logo': 'klara.jpg', 'url': 'http://mp3.streampower.be/klara'}
stations['klaracont']		= {'title': 'Radio Klara Continuo', 'logo': 'klara.jpg', 'url': 'http://mp3.streampower.be/klaracontinuo'}
stations['klarajazz']		= {'title': 'Radio Klara Jazz', 'logo': 'klara.jpg', 'url': 'http://mp3.streampower.be/klara_jazz'}
stations['stubru']			= {'title': 'Studio Brussel', 'logo': 'stubru.png', 'url': 'http://mp3.streampower.be/stubru'}
stations['stubruri']		= {'title': 'Studio Brussel Rock It', 'logo': 'stubru.png', 'url': 'http://mp3.streampower.be/stubru_rock_it'}
stations['mnm']				= {'title': 'MNM', 'logo': 'mnm.jpg', 'url': 'http://mp3.streampower.be/mnm'}
stations['mnmhits']			= {'title': 'MNM Hits', 'logo': 'mnm.jpg', 'url': 'http://mp3.streampower.be/mnm_hits'}
stations['rvinfo']			= {'title': 'Radio Vlaanderen Info', 'logo': 'rvi.jpg', 'url': 'http://mp3.streampower.be/rvi'}
stations['rv']				= {'title': 'Radio Vlaanderen', 'logo': 'rvi.jpg', 'url': 'http://mp3.streampower.be/rv'}

# groups info
stationgroups = {}
stationgroups['radio1']	= {'title': 'Radio 1', 'logo': 'radio1.jpg', 'stations': ['radio1', 'radio1classics'], 'description': 'Radio 1 profileert zich als een net voor luisteraars die ge�nformeerd willen worden; een soort van venster op de wereld. Onder het motto Meteen mee wil Radio 1 staan voor een mengeling van informatieve en ontspannende programma\'s. Radio 1 volgt niet alleen de actualiteit op de voet, maar biedt ook humor, tips en weetjes. De muziekkeuze bestaat uit vele genres en gebieden, streken en stijlen.'}
stationgroups['radio2']	= {'title': 'Radio 2', 'logo': 'radio2.jpg', 'stations': ['radio2ant', 'radio2vlb', 'radio2lim', 'radio2ovl', 'radio2wvl', 'radio2txl'], 'description': 'Radio 2 profileert zich als een populaire gezinsradio. De muziek is herkenbaar en melodisch.'}
stationgroups['klara']	= {'title': 'Radio Klara', 'logo': 'klara.jpg', 'stations': ['klara', 'klaracont', 'klarajazz'], 'description': 'Klara is een radiozender van de VRT die vooral klassieke muziek uitzendt.'}
stationgroups['stubru']	= {'title': 'Studio Brussel', 'logo': 'stubru.png', 'stations': ['stubru', 'stubruri'], 'description': 'Deze zender speelt veeleer alternatievere en zwaardere muziek die niet of weinig aan bod komen op de meer commerci�le zenders, vooral rock, maar ook metal, hiphop, house en techno. Hij heeft het imago alternatieve muziek veel kansen te geven en niet aan populisme te doen.'}
stationgroups['mnm']	= {'title': 'MNM', 'logo': 'mnm.jpg', 'stations': ['mnm', 'mnmhits'], 'description': 'MNM is een Vlaamse radiozender van de openbare omroep VRT. Zijn slagzin luidt: Let\'s have a big time. MNM draait hits van eind de jaren 80 tot nu. Vooral pop, poprock, dance en top 50-muziek.'}
stationgroups['rv']		= {'title': 'Radio Vlaanderen', 'logo': 'rvi.jpg', 'stations': ['rv', 'rvinfo'], 'description': 'Radio Vlaanderen of RV en Radio Vlaanderen Info of RVi zijn de internationale radiokanalen van de VRT.'}




def addStationGroupsToBoxee():
	# add the station groups to the list
	window        = mc.GetWindow(14000)
	stationlist   = window.GetList(2500)
	sglist        = mc.ListItems()

	# loop through stations
	for key in stationgroups.keys():
		stationsinfo = stationgroups[key]

		descr = stationsinfo['description']
		desc2 = '';
		title = stationsinfo['title']
		logo  = stationsinfo['logo']
		subs  = stationsinfo['stations']

		# loop through sub stations
		for stationKey in subs:
			stationInfo = stations[stationKey]


			if len(desc2) > 0:
				desc2 = desc2 + ', ' + stationInfo['title']
			else:
				desc2 = stationInfo['title']

		item = createStationGroupItem(title, descr + "\nStations: " + desc2, logo, key)
		sglist.append(item)

	stationlist.SetItems(sglist)

	return


def getSubstationsString(key):
	# get all substation as a string
	stationinfo = stationgroups[key]
	subs		= stationsinfo['stations']
	str			= ''

	for stationKey in subs:
		stationInfo = stations[stationKey]

		if len(str) > 0:
			str = str + ', ' + stationInfo['title']
		else:
			str = stationInfo['title']

	return str


def createStationGroupItem(name, info, logo, key):
	# create a list item
	item = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)

	item.SetLabel(name)
	item.SetDescription(info)
	item.SetThumbnail(logo)
	item.SetImage(0, logo)
	item.SetProperty('key', key)

	return item


def createRadioStationItem(name, key, url):
	# create a list item
	item = mc.ListItem(mc.ListItem.MEDIA_AUDIO_RADIO)
	item.SetIcon('icon_menu_music')
	item.SetLabel(name)
	item.SetPath(url + '-' + getQuality() + '.mp3')
	item.SetProperty('key', key)

	return item



def selectStation():
	# select windows
	mainWindow		= mc.GetWindow(14000)
	dialogWindow	= mc.GetWindow(14001)

	# select main window controls
	mainList		= mainWindow.GetList(2500)

	# select dialog controls
	stationList		= dialogWindow.GetList(5000)
	stationName		= dialogWindow.GetLabel(2500)
	stationLogo		= dialogWindow.GetImage(2400)

	# get radio station
	itemNr			= mainList.GetFocusedItem()
	item			= mainList.GetItem(itemNr)
	stationKey		= item.GetProperty('key')

	# get station info + update dialog (crappy textbox label update)
	station = stationgroups[stationKey]

	stationName.SetLabel(station['title'])
	stationLogo.SetTexture(station['logo'])
	xbmc.executebuiltin('Control.SetLabel(2600,' + station['description'].replace(',', '$COMMA') + ')')

	radios = mc.ListItems()


	for radio in station['stations']:
		item = createRadioStationItem(stations[radio]['title'], radio, stations[radio]['url'])
		radios.append(item)

	print radios
	print len(radios)

	stationList.SetItems(radios)


def startPlaying():
	# select window
	dialogWindow	= mc.GetWindow(14001)
	mainList		= dialogWindow.GetList(5000)

	# get radio station
	itemNr			= mainList.GetFocusedItem()
	item			= mainList.GetItem(itemNr)

	# info
	title			= item.GetLabel()
	quality			= getQuality()

	# playing
	player			= mc.GetPlayer()
	player.Play(item)

	# show info
	mc.ShowDialogNotification('starting ' + title + ' in ' + quality + ' quality')

	# close dialog (with dirty xbmc hack)
	xbmc.executebuiltin('Dialog.CLose(14001)')


def showQuality():
	# select the right quality in the settings dialog
	dialogWindow	= mc.GetWindow(14003)
	quality			= getQuality()
	selectQuality(quality)


def selectQuality(sender):
	# change quality, display options
	dialogWindow	= mc.GetWindow(14003)
	toggleLow		= dialogWindow.GetToggleButton(9100)
	toggleMid		= dialogWindow.GetToggleButton(9200)
	toggleHigh		= dialogWindow.GetToggleButton(9300)

	if sender == 'high':
		toggleLow.SetSelected(False)
		toggleMid.SetSelected(False)
		toggleHigh.SetSelected(True)

	elif sender == 'mid':
		toggleLow.SetSelected(False)
		toggleMid.SetSelected(True)
		toggleHigh.SetSelected(False)

	else:
		sender = 'low'
		toggleLow.SetSelected(True)
		toggleMid.SetSelected(False)
		toggleHigh.SetSelected(False)

	setQuality(sender)



def setQuality(newQuality):
	# save users quality choice
	config	= mc.GetApp().GetLocalConfig()
	config.SetValue('vrtplayer_quality', newQuality)


def getQuality():
	# get the quality
	config	= mc.GetApp().GetLocalConfig()
	quality	= config.GetValue('vrtplayer_quality')

	return quality
