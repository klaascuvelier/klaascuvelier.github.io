<?php
include_once "/Users/klaascuvelier/Zend/workspaces/DefaultWorkspace7/Netlogmedia/wp-content/plugins/contest-manager/php/classes/../qs_extensions//qse_dateformat.php";

?><link rel='stylesheet' href='/wp-content/plugins/contest-manager/css/frontend.css' type='text/css' media='all' /> 
<link rel='stylesheet' href='/wp-content/plugins/contest-manager/css/admin.css' type='text/css' media='all' /> 
<div class="wrap">
	<h2>Contest Manager</h2>
	

<?php
if (!empty($_obj['actionState'])){
?>
<?php
echo $_obj['actionState'];
?>
	
<?php
}
?>

<h3>Running and active contests</h3>
<?php
if (!empty($_obj['runningContests'])){
if (!is_array($_obj['runningContests']))
$_obj['runningContests']=array(array('runningContests'=>$_obj['runningContests']));
$_stack[$_stack_cnt++]=$_obj;
$rowcounter = 0;
foreach ($_obj['runningContests'] as $rowcnt=>$runningContests) {
$runningContests['ROWCNT']=($rowcounter);
$runningContests['ALTROW']=$rowcounter%2;
$runningContests['ROWBIT']=$rowcounter%2;
$rowcounter++;$_obj=&$runningContests;
?>
	<table cellpadding="10" cellspacing="2" border="0" class="widefat">
	<thead>
		<tr>
			<th style="width: 5%">ID</th>
			<th style="width: 40%">Title</th>
			<th style="width: 15%">Start</th>
			<th style="width: 15%">End</th>
			<th style="width: 5%">Active</th>
			<th style="width: 5%">Results</th>
			<th style="width: 15%">Actions</th>
		</tr>
	</thead>
	
	<?php
if (!empty($_obj['contests'])){
if (!is_array($_obj['contests']))
$_obj['contests']=array(array('contests'=>$_obj['contests']));
$_stack[$_stack_cnt++]=$_obj;
$rowcounter = 0;
foreach ($_obj['contests'] as $rowcnt=>$contests) {
$contests['ROWCNT']=($rowcounter);
$contests['ALTROW']=$rowcounter%2;
$contests['ROWBIT']=$rowcounter%2;
$rowcounter++;$_obj=&$contests;
?>
	<tr class="<?php
if (!empty($_obj['ALTROW'])){
?>odd<?php
} else {
?>even<?php
}
?>">
		<td style="text-align: right; text-indent: 0;"><?php
echo $_obj['contestID'];
?>
.&nbsp;</td>
		<td><?php
echo $_obj['title'];
?>
</td>
		<td><?php
echo qse_dateformat($_obj['startDate'], 'd/m/Y');
?>
</td>
		<td><?php
echo qse_dateformat($_obj['endDate'], 'd/m/Y');
?>
</td>
		<td><?php
echo $_obj['active'];
?>
</td>
		<td>
			<a href="<?php
echo $_stack[0]['url'];
?>
&view=results&contestid=<?php
echo $_obj['contestID'];
?>
">view</a>
		</td>
		<td>
			<a href="<?php
echo $_stack[0]['url'];
?>
&view=edit&contestid=<?php
echo $_obj['contestID'];
?>
">Edit</a>&nbsp;
			<a href="<?php
echo $_stack[0]['url'];
?>
&view=
				<?php
if ($_obj['active'] == "YES"){
?>close<?php
} else {
?>open<?php
}
?>			
				&contestid=<?php
echo $_obj['contestID'];
?>
"><?php
if ($_obj['active'] == "YES"){
?>Close<?php
} else {
?>Open<?php
}
?></a>&nbsp;
			<a href="<?php
echo $_stack[0]['url'];
?>
&view=delete&contestid=<?php
echo $_obj['contestID'];
?>
">Delete</a>			
			<a href="<?php
echo $_stack[0]['url'];
?>
&view=winners&contestid=<?php
echo $_obj['contestID'];
?>
">Winners</a>			
		</td>
	</tr>
	<?php
}
$_obj=$_stack[--$_stack_cnt];}
?>
</table>
<?php
}
$_obj=$_stack[--$_stack_cnt];}
?>

<h3>Finished or closed contests</h3>
<?php
if (!empty($_obj['finishedContests'])){
if (!is_array($_obj['finishedContests']))
$_obj['finishedContests']=array(array('finishedContests'=>$_obj['finishedContests']));
$_stack[$_stack_cnt++]=$_obj;
$rowcounter = 0;
foreach ($_obj['finishedContests'] as $rowcnt=>$finishedContests) {
$finishedContests['ROWCNT']=($rowcounter);
$finishedContests['ALTROW']=$rowcounter%2;
$finishedContests['ROWBIT']=$rowcounter%2;
$rowcounter++;$_obj=&$finishedContests;
?>
	<table cellpadding="10" cellspacing="2" border="0" class="widefat">
	<thead>
		<tr>
			<th style="width: 5%">ID</th>
			<th style="width: 40%">Title</th>
			<th style="width: 15%">Start</th>
			<th style="width: 15%">End</th>
			<th style="width: 5%">Active</th>
			<th style="width: 5%">Results</th>
			<th style="width: 15%">Actions</th>
		</tr>
	</thead>
	
	<?php
if (!empty($_obj['contests'])){
if (!is_array($_obj['contests']))
$_obj['contests']=array(array('contests'=>$_obj['contests']));
$_stack[$_stack_cnt++]=$_obj;
$rowcounter = 0;
foreach ($_obj['contests'] as $rowcnt=>$contests) {
$contests['ROWCNT']=($rowcounter);
$contests['ALTROW']=$rowcounter%2;
$contests['ROWBIT']=$rowcounter%2;
$rowcounter++;$_obj=&$contests;
?>
	<tr class="<?php
if (!empty($_obj['ALTROW'])){
?>odd<?php
} else {
?>even<?php
}
?>">
		<td style="text-align: right; text-indent: 0;"><?php
echo $_obj['contestID'];
?>
.&nbsp;</td>
		<td><?php
echo $_obj['title'];
?>
</td>
		<td><?php
echo qse_dateformat($_obj['startDate'], 'd/m/Y');
?>
</td>
		<td><?php
echo qse_dateformat($_obj['endDate'], 'd/m/Y');
?>
</td>
		<td><?php
echo $_obj['active'];
?>
</td>
		<td>
			<a href="<?php
echo $_stack[0]['url'];
?>
&view=results&contestid=<?php
echo $_obj['contestID'];
?>
">view</a>
		</td>
		<td>
			<a href="<?php
echo $_stack[0]['url'];
?>
&view=edit&contestid=<?php
echo $_obj['contestID'];
?>
">Edit</a>&nbsp;
			<a href="<?php
echo $_stack[0]['url'];
?>
&view=
				<?php
if ($_obj['active'] == "YES"){
?>close<?php
} else {
?>open<?php
}
?>			
				&contestid=<?php
echo $_obj['contestID'];
?>
"><?php
if ($_obj['active'] == "YES"){
?>Close<?php
} else {
?>Open<?php
}
?></a>&nbsp;
			<a href="<?php
echo $_stack[0]['url'];
?>
&view=delete&contestid=<?php
echo $_obj['contestID'];
?>
">Delete</a>			
			<a href="<?php
echo $_stack[0]['url'];
?>
&view=winners&contestid=<?php
echo $_obj['contestID'];
?>
">Winners</a>			
		</td>
	</tr>
	<?php
}
$_obj=$_stack[--$_stack_cnt];}
?>
</table>
<?php
}
$_obj=$_stack[--$_stack_cnt];}
?>
</div>
<script type='text/javascript' src='/wp-content/plugins/contest-manager/js/pager.js'></script>
<script type='text/javascript' src='/wp-content/plugins/contest-manager/js/contest.js'></script>