<?php
include_once "/Users/klaascuvelier/Zend/workspaces/DefaultWorkspace7/Netlogmedia/wp-content/plugins/contest-manager/php/classes/../qs_extensions//qse_escapetext.php";
include_once "/Users/klaascuvelier/Zend/workspaces/DefaultWorkspace7/Netlogmedia/wp-content/plugins/contest-manager/php/classes/../qs_extensions//qse_dateformat.php";

?><link rel='stylesheet' href='/wp-content/plugins/contest-manager/css/frontend.css' type='text/css' media='all' /> 
<link rel='stylesheet' href='/wp-content/plugins/contest-manager/css/admin.css' type='text/css' media='all' /> 
<div class="wrap">
	<h2>Contest Manager</h2>
	

<h3>Results for: <?php
echo qse_escapetext($_obj['contest']['title']);
?>
 (<a href="/wp-admin/admin.php?page=contest-manager.php&view=edit&contestid=<?php
echo $_obj['contest']['contestID'];
?>
">edit</a>)</h3>

<h4>Contest info</h4>

<table class="widefat">
	<tr class="odd">
		<th style="width: 15%">Title</th>
		<td style="width: 40%"><?php
echo qse_escapetext($_obj['contest']['title']);
?>
</td>
		<th style="width: 15%" rowspan="5">Votes</th>
		<td style="width: 30%; background: transparent url('/wp-admin/images/loading.gif') center center no-repeat;" rowspan="5">
			<div id="chart"></div>
		</td>
	</tr>
	<tr class="even">
		<th>Question</th>
		<td><?php
echo qse_escapetext($_obj['contest']['question']);
?>
</td>
	</tr>
	<tr class="odd">
		<th>Start date</th>
		<td><?php
echo qse_dateformat($_obj['contest']['startDate'],'d/m/Y');
?>
</td>
	</tr>
	<tr class="even">
		<th>End date</th>
		<td><?php
echo qse_dateformat($_obj['contest']['endDate'],'d/m/Y');
?>
</td>
	</tr>
	<tr class="odd">
		<th>Winners</th>
		<td>
			<?php
if (!empty($_obj['winners'])){
?>
			<ul id="winners-inl">
				<?php
if (!empty($_obj['winners'])){
if (!is_array($_obj['winners']))
$_obj['winners']=array(array('winners'=>$_obj['winners']));
$_stack[$_stack_cnt++]=$_obj;
$rowcounter = 0;
foreach ($_obj['winners'] as $rowcnt=>$winners) {
$winners['ROWCNT']=($rowcounter);
$winners['ALTROW']=$rowcounter%2;
$winners['ROWBIT']=$rowcounter%2;
$rowcounter++;$_obj=&$winners;
?>
				<li><?php
echo qse_escapetext($_obj['firstName']);
?>
 <?php
echo qse_escapetext($_obj['lastName']);
?>
 (<?php
echo qse_escapetext($_obj['company']);
?>
)</li>
				<?php
}
$_obj=$_stack[--$_stack_cnt];}
?>
			</ul>
			<?php
}
?>
			<a href="<?php
echo $_obj['url'];
?>
&view=winners&contestid=<?php
echo $_obj['contest']['contestID'];
?>
">Pick winners</a>
		</td>
	</tr>			
</table>


<h4>Participants (<?php
echo $_obj['participantsCount'];
?>
)</h4>
<div class="ajax-placeholder" id="ajax_<?php
echo $_obj['pager_ajaxPagerID'];
?>
">
	<table cellpadding="10" cellspacing="2" border="0" class="widefat">
	<thead>
		<tr>
			<th>First name</th>
			<th>Last name</th>
			<th>Company</th>
			<th>Function</th>
			<th>Email</th>
			<th>Remind</th>
			<th>Winner</th>
		</tr>
	</thead>
	
	<?php
if (!empty($_obj['participants'])){
if (!is_array($_obj['participants']))
$_obj['participants']=array(array('participants'=>$_obj['participants']));
$_stack[$_stack_cnt++]=$_obj;
$rowcounter = 0;
foreach ($_obj['participants'] as $rowcnt=>$participants) {
$participants['ROWCNT']=($rowcounter);
$participants['ALTROW']=$rowcounter%2;
$participants['ROWBIT']=$rowcounter%2;
$rowcounter++;$_obj=&$participants;
?>
	<tr class="<?php
if (!empty($_obj['ALTROW'])){
?>odd<?php
} else {
?>even<?php
}
?>">
		<td><?php
echo qse_escapetext($_obj['firstName']);
?>
</td>
		<td><?php
echo qse_escapetext($_obj['lastName']);
?>
</td>
		<td><?php
echo qse_escapetext($_obj['company']);
?>
</td>
		<td><?php
echo qse_escapetext($_obj['function']);
?>
</td>
		<td><?php
echo qse_escapetext($_obj['email']);
?>
</td>
		<td><?php
if ($_obj['remindMe'] == "YES"){
?>YES<?php
}
?></td>
		<td><?php
if ($_obj['winner'] == "YES"){
?>YES<?php
}
?></td>
	</tr>
	<?php
}
$_obj=$_stack[--$_stack_cnt];}
?>
</table>
</div>
<?php
echo $_obj['pager_html'];
?>



<!-- load Google AJAX API -->  
<script type="text/javascript" src="http://www.google.com/jsapi"></script>  
<script type="text/javascript">  
	google.load('visualization', '1', {'packages':['corechart']});  
	google.setOnLoadCallback (function () {
		  
        var data = new google.visualization.DataTable();

		data.addColumn('string', 'Date');
		data.addColumn('number', 'Votes');
		data.addRows(<?php echo sizeof($_obj['voteData']); ?>);

<?php
if (!empty($_obj['voteData'])){
if (!is_array($_obj['voteData']))
$_obj['voteData']=array(array('voteData'=>$_obj['voteData']));
$_stack[$_stack_cnt++]=$_obj;
$rowcounter = 0;
foreach ($_obj['voteData'] as $rowcnt=>$voteData) {
$voteData['ROWCNT']=($rowcounter);
$voteData['ALTROW']=$rowcounter%2;
$voteData['ROWBIT']=$rowcounter%2;
$rowcounter++;$_obj=&$voteData;
?>
		data.setValue(<?php
echo $_obj['ROWCNT'];
?>
 , 0, '<?php
echo $_obj['date'];
?>
');
		data.setValue(<?php
echo $_obj['ROWCNT'];
?>
 , 1, <?php
echo $_obj['votes'];
?>
);
<?php
}
$_obj=$_stack[--$_stack_cnt];}
?>
                

		var chart = new google.visualization.LineChart(document.getElementById('chart'));
		chart.draw(data, { width: 440, height: 240, legend: 'none', curveType: 'function' });  
  
	});  
</script>  
<!-- end Google AJAX API -->
</div>
<script type='text/javascript' src='/wp-content/plugins/contest-manager/js/pager.js'></script>
<script type='text/javascript' src='/wp-content/plugins/contest-manager/js/contest.js'></script>