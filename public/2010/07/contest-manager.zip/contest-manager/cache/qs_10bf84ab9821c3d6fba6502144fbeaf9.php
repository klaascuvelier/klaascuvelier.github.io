<?php include_once(dirname(__FILE__) . '/../php/qs_extensions/qse_gotopage.php'); ?>
<ul class="pager" id="pager_<?php
echo $_obj['pagerID'];
?>
">
<?php
if ($_obj['pages'] <= "5"){
?>
	<?php for ($i = 1; $i <= $_obj['pages']; $i++) { $_obj['data'] = array($i, $_obj['pages']); ?>
		<li>
		<?php echo qse_gotopage($i, $_obj['pages'], $_obj['url']); ?>
		</li>

	<?php }?>
<?php
}
?>


</ul>