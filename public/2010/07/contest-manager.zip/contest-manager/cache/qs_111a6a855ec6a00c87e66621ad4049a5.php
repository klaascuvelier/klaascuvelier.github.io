<?php
include_once "/Users/klaascuvelier/Zend/workspaces/DefaultWorkspace7/Netlogmedia/wp-content/plugins/contest-manager/php/classes/../qs_extensions//qse_escapetext.php";
include_once "/Users/klaascuvelier/Zend/workspaces/DefaultWorkspace7/Netlogmedia/wp-content/plugins/contest-manager/php/classes/../qs_extensions//qse_dateformat.php";

?><link rel='stylesheet' href='/wp-content/plugins/contest-manager/css/frontend.css' type='text/css' media='all' /> 
<link rel='stylesheet' href='/wp-content/plugins/contest-manager/css/admin.css' type='text/css' media='all' /> 
<div class="wrap">
	<h2>Contest Manager</h2>
	

<h3>Pick winners for for: <?php
echo qse_escapetext($_obj['contest']['title']);
?>
 (<a href="/wp-admin/admin.php?page=contest-manager.php&view=edit&contestid=<?php
echo $_obj['contest']['contestID'];
?>
">edit</a>)</h3>

<h4>Contest info</h4>

<table class="widefat">
	<tr class="odd">
		<th style="width: 15%">Title</th>
		<td style="width: 40%"><?php
echo qse_escapetext($_obj['contest']['title']);
?>
</td>
		<th style="width: 15%" rowspan="5">Votes</th>
		<td style="width: 30%; background: transparent url('/wp-admin/images/loading.gif') center center no-repeat;" rowspan="4">
			<div id="chart"></div>
		</td>
	</tr>
	<tr class="even">
		<th>Question</th>
		<td><?php
echo qse_escapetext($_obj['contest']['question']);
?>
</td>
	</tr>
	<tr class="odd">
		<th>Start date</th>
		<td><?php
echo qse_dateformat($_obj['contest']['startDate'],'d/m/Y');
?>
</td>
	</tr>
	<tr class="even">
		<th>End date</th>
		<td><?php
echo qse_dateformat($_obj['contest']['endDate'],'d/m/Y');
?>
</td>
	</tr>
</table>
<!-- load Google AJAX API -->  
<script type="text/javascript" src="http://www.google.com/jsapi"></script>  
<script type="text/javascript">  
	google.load('visualization', '1', {'packages':['corechart']});  
	google.setOnLoadCallback (function () {
		  
        var data = new google.visualization.DataTable();

		data.addColumn('string', 'Date');
		data.addColumn('number', 'Votes');
		data.addRows(<?php echo sizeof($_obj['voteData']); ?>);

<?php
if (!empty($_obj['voteData'])){
if (!is_array($_obj['voteData']))
$_obj['voteData']=array(array('voteData'=>$_obj['voteData']));
$_stack[$_stack_cnt++]=$_obj;
$rowcounter = 0;
foreach ($_obj['voteData'] as $rowcnt=>$voteData) {
$voteData['ROWCNT']=($rowcounter);
$voteData['ALTROW']=$rowcounter%2;
$voteData['ROWBIT']=$rowcounter%2;
$rowcounter++;$_obj=&$voteData;
?>
		data.setValue(<?php
echo $_obj['ROWCNT'];
?>
 , 0, '<?php
echo $_obj['date'];
?>
');
		data.setValue(<?php
echo $_obj['ROWCNT'];
?>
 , 1, <?php
echo $_obj['votes'];
?>
);
<?php
}
$_obj=$_stack[--$_stack_cnt];}
?>
                

		var chart = new google.visualization.LineChart(document.getElementById('chart'));
		chart.draw(data, { width: 440, height: 240, legend: 'none', curveType: 'function' });  
  
	});  
</script>  
<!-- end Google AJAX API -->

<?php
if (!empty($_obj['contest']['open'])){
?>
<br />
<div class="error">You can't select winners if the contest is still running.</div>
<?php
} else {
?>
<form action="<?php
echo $_obj['url'];
?>
&view=winners&contestid=<?php
echo $_obj['contest']['contestID'];
?>
" method="post">
	<input type="hidden" name="action" value="__button" />
	
	<h4>Winners</h4>
	<?php
if (!empty($_obj['winners'])){
?><?php
} else {
?>
	<i>No winners yet, please select them below</i><br />
	<?php
}
?>
	<ul id="winners">
		<?php
if (!empty($_obj['winners'])){
if (!is_array($_obj['winners']))
$_obj['winners']=array(array('winners'=>$_obj['winners']));
$_stack[$_stack_cnt++]=$_obj;
$rowcounter = 0;
foreach ($_obj['winners'] as $rowcnt=>$winners) {
$winners['ROWCNT']=($rowcounter);
$winners['ALTROW']=$rowcounter%2;
$winners['ROWBIT']=$rowcounter%2;
$rowcounter++;$_obj=&$winners;
?>
		<li>
			<input type="submit" class="deleteWinner" value="<?php
echo qse_escapetext($_obj['firstName']);
?>
 <?php
echo qse_escapetext($_obj['lastName']);
?>
 (<?php
echo qse_escapetext($_obj['company']);
?>
)" name="btn__deleteWinner__<?php
echo $_obj['participantID'];
?>
" />
			<input type="hidden" value="<?php
echo $_obj['participantID'];
?>
" name="winner__<?php
echo $_obj['participantID'];
?>
" />
		</li>
		<?php
}
$_obj=$_stack[--$_stack_cnt];}
?>
	</ul><br />
	<input type="submit" name="btn__saveWinners" value="Save" />


	<h4>Participants with correct answers</h4>
	
	<table cellpadding="10" cellspacing="2" border="0" class="widefat">
		<thead>
			<tr>
				<th>First name</th>
				<th>Last name</th>
				<th>Company</th>
				<th>Function</th>
				<th>Email</th>
				<th>Diff from bonus</th>
				<th>Action</th>
			</tr>
		</thead>
		
		<?php
if (!empty($_obj['participants'])){
if (!is_array($_obj['participants']))
$_obj['participants']=array(array('participants'=>$_obj['participants']));
$_stack[$_stack_cnt++]=$_obj;
$rowcounter = 0;
foreach ($_obj['participants'] as $rowcnt=>$participants) {
$participants['ROWCNT']=($rowcounter);
$participants['ALTROW']=$rowcounter%2;
$participants['ROWBIT']=$rowcounter%2;
$rowcounter++;$_obj=&$participants;
?>
		<tr id="participant_<?php
echo $_obj['participantID'];
?>
" class="<?php
if (!empty($_obj['ALTROW'])){
?>odd<?php
} else {
?>even<?php
}
?>">
			<td class="firstname"><?php
echo qse_escapetext($_obj['firstName']);
?>
</td>
			<td class="lastname"><?php
echo qse_escapetext($_obj['lastName']);
?>
</td>
			<td class="company"><?php
echo qse_escapetext($_obj['company']);
?>
</td>
			<td><?php
echo qse_escapetext($_obj['function']);
?>
</td>
			<td><?php
echo qse_escapetext($_obj['email']);
?>
</td>
			<td><?php
echo $_obj['diffBonus'];
?>
</td>
			<td><input type="submit" class="linkbutton pickWinner" name="btn__pickWinner__<?php
echo $_obj['participantID'];
?>
" value="pick" /></td>
		</tr>
		<?php
}
$_obj=$_stack[--$_stack_cnt];}
?>
		
		<?php
if (!empty($_obj['picked'])){
if (!is_array($_obj['picked']))
$_obj['picked']=array(array('picked'=>$_obj['picked']));
$_stack[$_stack_cnt++]=$_obj;
$rowcounter = 0;
foreach ($_obj['picked'] as $rowcnt=>$picked) {
$picked['ROWCNT']=($rowcounter);
$picked['ALTROW']=$rowcounter%2;
$picked['ROWBIT']=$rowcounter%2;
$rowcounter++;$_obj=&$picked;
?>
		<tr id="participant_<?php
echo $_obj['participantID'];
?>
" class="<?php
if (!empty($_obj['ALTROW'])){
?>odd<?php
} else {
?>even<?php
}
?> isWinner">
			<td class="firstname"><?php
echo qse_escapetext($_obj['firstName']);
?>
</td>
			<td class="lastname"><?php
echo qse_escapetext($_obj['lastName']);
?>
</td>
			<td class="company"><?php
echo qse_escapetext($_obj['company']);
?>
</td>
			<td><?php
echo qse_escapetext($_obj['function']);
?>
</td>
			<td><?php
echo qse_escapetext($_obj['email']);
?>
</td>
			<td><?php
echo $_obj['diffBonus'];
?>
</td>
			<td><input type="submit" class="linkbutton pickWinner" name="btn__pickWinner__<?php
echo $_obj['participantID'];
?>
" value="pick" /></td>
		</tr>
		<?php
}
$_obj=$_stack[--$_stack_cnt];}
?>		
	</table>
</form>
<?php
}
?>
</div>
<script type='text/javascript' src='/wp-content/plugins/contest-manager/js/pager.js'></script>
<script type='text/javascript' src='/wp-content/plugins/contest-manager/js/contest.js'></script>