<link rel='stylesheet' href='/wp-content/plugins/contest-manager/css/frontend.css' type='text/css' media='all' /> 
<link rel='stylesheet' href='/wp-content/plugins/contest-manager/css/admin.css' type='text/css' media='all' /> 
<div class="wrap">
	<h2>Contest Manager</h2>
	

<?php
if ($_obj['action'] == "update"){
?>
 	<h3>Edit contest</h3>
<?php
} else {
?>
	<h3>Add new contest</h3>
<?php
}
?>

<?php
if ($_obj['actionState'] == "addContestFailure"){
?>
<div class="error">Could not add the contest. Please check errors.</div>
<?php
}
?>

<form action="<?php
if ($_obj['action'] == "update"){
?><?php
echo $_obj['url'];
?>
&view=edit&contestid=<?php
echo $_obj['form']['contestContestID'];
?>
<?php
} else {
?><?php
echo $_obj['url'];
?>
&view=add<?php
}
?>" method="post">
	<input type="hidden" name="action" value="__button" />
	<input type="hidden" name="currentAction" value="<?php
echo $_obj['action'];
?>
" />
	<input type="hidden" name="contestContestID" value="<?php
echo $_obj['form']['contestContestID'];
?>
" />

	<table class="widefat">
		<thead>
			<tr>
				<th style="width: 25%">Property</th>
				<th>Value</th>
			</tr>
		</thead>
		
		<tbody>
			<tr class="odd">
				<td><label for="contestName" class="<?php
if (!empty($_obj['errors']['contestName'])){
?>error<?php
}
?>">Contest name</label></td>
				<td><input type="text" name="contestName" id="contestName" value="<?php
echo $_obj['form']['contestName'];
?>
" class="text required" /></td>
			</tr>
			<tr class="even">
				<td><label for="contestQuestion" class="<?php
if (!empty($_obj['errors']['contestQuestion'])){
?>error<?php
}
?>">Question</label></td>
				<td><textarea name="contestQuestion" id="contestQuestion" rows="5" cols="80"><?php
echo $_obj['form']['contestQuestion'];
?>
</textarea></td>
			</tr>
			<tr class="odd">
				<td><label for="contestStartDate" class="<?php
if (!empty($_obj['errors']['contestStartDate'])){
?>error<?php
}
?>">Start date</label></td>
				<td>
					<input type="text" name="contestStartDate" id="contestStartDate" value="<?php
echo $_obj['form']['contestStartDate'];
?>
" class="text required pickDate" />
				</td>
			</tr>
			<tr class="even">
				<td><label for="contestEndDate" class="<?php
if (!empty($_obj['errors']['contestEndDate'])){
?>error<?php
}
?>">End date</label> <small>(end date included)</small></td>
				<td>
					<input type="text" name="contestEndDate" id="contestEndDate" value="<?php
echo $_obj['form']['contestEndDate'];
?>
" class="text required pickDate" />
				</td>
			</tr>
			<tr class="odd">
				<td><label for="contestActive" class="<?php
if (!empty($_obj['errors']['contestActive'])){
?>error<?php
}
?>">Active</label></td>
				<td>
					<input type="radio" name="contestActive" id="contestActiveYes" value="YES" <?php
if ($_obj['form']['contestActive'] != "NO"){
?>checked="checked" <?php
}
?>class="radio" /><label for="contestActiveYes">Yes</label><br />
					<input type="radio" name="contestActive" id="contestActiveNo" value="NO" <?php
if ($_obj['form']['contestActive'] == "NO"){
?>checked="checked"<?php
}
?>class="radio" /><label for="contestActiveNo">No</label>
				</td>
			</tr>
			<tr class="even">
				<td><label for="contestBonusQuestion" class="<?php
if (!empty($_obj['errors']['contestBonusQuestion'])){
?>error<?php
}
?>">Bonus question</label></td>
				<td><input type="text" name="contestBonusQuestion" id="contestBonusQuestion" value="<?php
echo $_obj['form']['contestBonusQuestion'];
?>
" class="text required" /></td>
			</tr>
			<tr class="odd">
				<td><label for="contestBonusAnswer" class="<?php
if (!empty($_obj['errors']['contestBonusAnswer'])){
?>error<?php
}
?>">Bonus answer</label><br /><small>please enter a number</small></td>
				<td><input type="text" name="contestBonusAnswer" id="contestBonusAnswer" value="<?php
echo $_obj['form']['contestBonusAnswer'];
?>
" class="text required" /></td>
			</tr>
		</tbody>
	</table>

	<h3>Answers</h3>

	<table class="widefat" id="contestAnswers">
		<thead>
			<tr>
				<th style="width: 5%">Correct</th>
				<th>Answer</th>
			</tr>
		</thead>
			
		<tbody>
			<?php
if (!empty($_obj['answers'])){
?>
				<?php
if (!empty($_obj['answers'])){
if (!is_array($_obj['answers']))
$_obj['answers']=array(array('answers'=>$_obj['answers']));
$_stack[$_stack_cnt++]=$_obj;
$rowcounter = 0;
foreach ($_obj['answers'] as $rowcnt=>$answers) {
$answers['ROWCNT']=($rowcounter);
$answers['ALTROW']=$rowcounter%2;
$answers['ROWBIT']=$rowcounter%2;
$rowcounter++;$_obj=&$answers;
?>
				<tr class="<?php
if (!empty($_obj['ALTROW'])){
?>odd<?php
} else {
?>even<?php
}
?>">
					<td><input type="radio" class="radio" name="contestAnswerCorrect" id="contestAnswerCorrect<?php
echo $_obj['ROWCNT'];
?>
" value="<?php
echo $_obj['ROWCNT'];
?>
"<?php
if (!empty($_obj['correct'])){
?> checked="checked"<?php
}
?> /></td>
					<td><input type="text" name="contestAnswer_<?php
echo $_obj['ROWCNT'];
?>
_<?php
echo $_obj['answerID'];
?>
" id="contestAnswer_<?php
echo $_obj['ROWCNT'];
?>
_<?php
echo $_obj['answerID'];
?>
" value="<?php
echo $_obj['answer'];
?>
" class="text required" /></td>
				</tr>
				<?php
}
$_obj=$_stack[--$_stack_cnt];}
?>
			<?php
} else {
?>
				<tr class="even">
					<td><input type="radio" class="radio" name="contestAnswerCorrect" id="contestAnswerCorrect1" value="1" checked="checked" /></td>
					<td><input type="text" name="contestAnswer1" id="contestAnswer_1_0" value="" class="text required" /></td>
				</tr>	
				<tr class="odd">
					<td><input type="radio" class="radio" name="contestAnswerCorrect" id="contestAnswerCorrect2" value="2" /></td>
					<td><input type="text" name="contestAnswer2" id="contestAnswer_2_0" value="" class="text required" /></td>
				</tr>					
			<?php
}
?>	
		</tbody>
	</table>
	
	<input type="submit" name="btn__addAnswer" id="addAnswer" value="Add answer" />
	
	<hr /><br />
	<?php
if ($_obj['action'] == "update"){
?>
		<input type="submit" name="btn__updateContest" value="Update contest" />	
	<?php
} else {
?>
		<input type="submit" name="btn__addContest" value="Add contest" />
	<?php
}
?>
</form>
 
<?php
if (!empty($_obj['form']['contestContestID'])){
?>
<h3>Post info</h3>
<div class="info">Add this contest to your post with this code:<br />
<pre>[contest_<?php
echo $_obj['form']['contestContestID'];
?>
]</pre></div>
<br /><br />
<?php
}
?>

<script src="http://jquery-ui.googlecode.com/svn/trunk/ui/jquery.ui.core.js"></script>
<script src="http://jquery-ui.googlecode.com/svn/trunk/ui/jquery.ui.datepicker.js"></script>
<link href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/themes/base/jquery-ui.css" rel="stylesheet" type="text/css"/>
</div>
<script type='text/javascript' src='/wp-content/plugins/contest-manager/js/pager.js'></script>
<script type='text/javascript' src='/wp-content/plugins/contest-manager/js/contest.js'></script>