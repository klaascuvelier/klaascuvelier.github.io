<?php
include_once "/Users/klaascuvelier/Zend/workspaces/DefaultWorkspace7/Netlogmedia/wp-content/plugins/contest-manager/php/classes/../qs_extensions//qse_escapetext.php";

?><table cellpadding="10" cellspacing="2" border="0" class="widefat">
	<thead>
		<tr>
			<th>First name</th>
			<th>Last name</th>
			<th>Company</th>
			<th>Function</th>
			<th>Email</th>
			<th>Remind</th>
			<th>Winner</th>
		</tr>
	</thead>
	
	<?php
if (!empty($_obj['participants'])){
if (!is_array($_obj['participants']))
$_obj['participants']=array(array('participants'=>$_obj['participants']));
$_stack[$_stack_cnt++]=$_obj;
$rowcounter = 0;
foreach ($_obj['participants'] as $rowcnt=>$participants) {
$participants['ROWCNT']=($rowcounter);
$participants['ALTROW']=$rowcounter%2;
$participants['ROWBIT']=$rowcounter%2;
$rowcounter++;$_obj=&$participants;
?>
	<tr class="<?php
if (!empty($_obj['ALTROW'])){
?>odd<?php
} else {
?>even<?php
}
?>">
		<td><?php
echo qse_escapetext($_obj['firstName']);
?>
</td>
		<td><?php
echo qse_escapetext($_obj['lastName']);
?>
</td>
		<td><?php
echo qse_escapetext($_obj['company']);
?>
</td>
		<td><?php
echo qse_escapetext($_obj['function']);
?>
</td>
		<td><?php
echo qse_escapetext($_obj['email']);
?>
</td>
		<td><?php
if ($_obj['remindMe'] == "YES"){
?>YES<?php
}
?></td>
		<td><?php
if ($_obj['winner'] == "YES"){
?>YES<?php
}
?></td>
	</tr>
	<?php
}
$_obj=$_stack[--$_stack_cnt];}
?>
</table>