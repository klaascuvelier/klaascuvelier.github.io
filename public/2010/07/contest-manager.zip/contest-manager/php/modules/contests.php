<?php

	/**
	 * WordPress contest plugin written for Netlog NV
	 * 
	 * @copyright 	Netlog NV (http://www.netlog.com)
	 * @author		Netlog NV  (http://www.netlog.com)
	 * @author 		Klaas Cuvelier, klaas@netlog.com (http://www.cuvedev.net)
	 * @link 		http://www.netlog.com, http://www.netlogmedia.com
	 * @version		1.0
	 * @license		GPL v2.0
	 * 
	 * Are you a talented developer or designer looking for a job? Check out http://www.netlog.jobs!
	 */

	class ContestsAction extends GenericAction 
	{
		/**
		 * @var ContestsManager
		 */
		protected $contestsManager;
		
		/**
		 * @var Contest
		 */
		protected $contest;
		
		protected $tmpWinners;
		
		
		public function __construct() 
		{
			// create contest manager
			$this->contestsManager 	= new ContestsManager();
			
			$this->tmpWinners		= array();
			
			// check if a contest needs to be loaded
			if (isset($_GET['contestid']) && is_numeric($_GET['contestid']))
			{
				$this->contest = new Contest($_GET['contestid']);
			}
			
			parent::__construct();
		}
		
		
		/**
		 * Display existing contests
		 */
		protected function displayIndex()
		{
			$this->page->setFilename('admin/admin.contests.index.tpl');

			$finished = $this->contestsManager->getAllContests(true, 0, 30);
			$running  = $this->contestsManager->getAllContests(false, 0, 30);
			
 			$this->page->assign('finishedContests'	, array(array('contests' => $finished)));
			$this->page->assign('runningContests'	, array(array('contests' => $running)));
			
			return true;
		}
		
		
		/**
		 * View results for existing contest
		 */
		protected function displayResults()
		{
			if (empty($this->contest) || $this->contest->getContestID() == 0)
			{
				$this->forward('/wp-admin/admin.php?page=contest-manager.php');
				return false;
			}
			
			$this->page->setFilename('admin/admin.contests.results.tpl');
			
			$participantsCount 	= $this->contest->getParticipantsCount();
			$pager 				= new Pager(10, $participantsCount);
			
			$this->page->assign('contest' 					, $this->contest->toArray());
			$this->page->assign('participantsCount'			, $participantsCount);
			$this->page->assign('voteData'					, $this->contestsManager->getVoteData($this->contest->getContestID()));
			$this->page->assign('participants'				, $this->contest->getParticipants($pager->getStart(), $pager->getLimit()));
			$this->page->assign('pager_html'				, $pager->getHtml());
			$this->page->assign('pager_ajaxPagerID'			, $pager->getPagerID());
			$this->page->assign('winners'					, $this->contest->getWinners());

			return true;
		}
		
		
		/**
		 * Display method for new contest
		 */
		protected function displayAdd()
		{
			$this->page->setFilename('admin/admin.contests.add.tpl');
		}
		
		
		/**
		 * Edit existing contest
		 */
		protected function displayEdit()
		{
			if (empty($this->contest) || $this->contest->getContestID() == 0)
			{
				$this->forward('/wp-admin/admin.php?page=contest-manager.php');
				return false;
			}
			
			$this->page->setFilename('admin/admin.contests.add.tpl');
			
			if (!isset($_POST['action']))
			{
				$contestInfo = $this->contest->toArray('contest');
				
				$contestInfo['contestEndDate']		= Date('d/m/Y', $contestInfo['contestEndDate']);
				$contestInfo['contestStartDate']	= Date('d/m/Y', $contestInfo['contestStartDate']);
				$contestInfo['contestName']			= $contestInfo['contestTitle'];
				
				$answers =  $this->contest->getAnswers();

				$this->page->assign('answers'	, $answers);
				$this->page->assign('form'		, $contestInfo);
			}
			
			$this->page->assign('action'	, 'update');
			
		}
		
		
		/**
		 * View selected winners for this contest
		 */
		protected function displayWinners()
		{
			if (empty($this->contest) || $this->contest->getContestID() == 0)
			{
				$this->forward('/wp-admin/admin.php?page=contest-manager.php');
				return false;
			}
			
			if (count($this->tmpWinners) < 1)
			{
				foreach ($this->contest->getWinners() as $winner)
				{
					$this->tmpWinners[$winner['participantID']] = $winner;
				}
				 
				$this->page->assign('winners', $this->tmpWinners);
			}
			
			$winners = $this->contest->getPossibleWinners();
			$picked	 = array();
			
			foreach ($winners as $index => $winner)
			{
				if (array_key_exists($winner['participantID'], $this->tmpWinners))
				{
					array_push($picked, $winner);
					unset($winners[$index]);
				}
			}
						
			$this->page->setFilename('admin/admin.contests.winners.tpl');
			$this->page->assign('contest' 		, $this->contest->toArray());
			$this->page->assign('voteData'		, $this->contestsManager->getVoteData($this->contest->getContestID()));
			$this->page->assign('participants'	, $winners);
			$this->page->assign('picked'		, $picked);
			
			
			return true;
		}
		
		
		/**
		 * (Re)Open current contest
		 */
		protected function displayOpen()
		{
			if (!empty($this->contest) && $this->contest->getContestID() > 0)
			{
				$this->contest->setActive('YES');
				$this->contest->updateContest();
			}			

			$this->forward('/wp-admin/admin.php?page=contest-manager.php');
		}
		
		
		/**
		 * Close current contest
		 */
		protected function displayClose()
		{
			if (!empty($this->contest) && $this->contest->getContestID() > 0)
			{
				$this->contest->setActive('NO');
				$this->contest->updateContest();
			}			

			$this->forward('/wp-admin/admin.php?page=contest-manager.php');
		}
		
		
		/**
		 * (non-PHPdoc)
		 * @see wp-content/plugins/contest-manager/php/modules/GenericAction#getActions()
		 */
		protected function getActions()
		{
			return array(
				'addContest'	=> 'addContestAction',
				'updateContest'	=> 'updateContestAction',
				'addAnswer'		=> 'addAnswerAction',
				'pickWinner'	=> 'pickWinnerAction',
				'deleteWinner'	=> 'deleteWinnerAction',
				'saveWinners'	=> 'saveWinnersAction',
			);
		}
		
		
		/**
		 * Add a new contest
		 */
		protected function addContestAction()
		{
			$this->validator->setPostOnly();
			
			$this->validator->setRequired(
				array('contestName', 'contestQuestion', 'contestStartDate', 'contestEndDate', 'contestActive', 'contestBonusQuestion', 'contestBonusAnswer')
			);
			
			$this->validator->setNumeric('contestBonusAnswer');
			$this->validator->setFormat(array('contestStartDate', 'contestEndDate'), '[0-9]{2}/[0-9]{2}/[0-9]{4}');

			if ($this->validator->hasErrors())
			{
				$this->page->assign('form'			, $_POST);
				$this->page->assign('answers'		, $this->getAnswersFromPost());
				$this->page->assign('errors'		, $this->validator->getErrors());
				$this->page->assign('actionState'	, 'addContestFailure');
			}
			else
			{
				$this->view = 'index';
				
				$this->contest = new Contest();
				$this->contest->fromArray($_POST, 'contest');
				$this->contest->setTitle($_POST['contestName']);
				$this->contest->setImageUrl('');
			
				if (!$this->contest->createContest())
				{
					$this->page->assign('actionState', 'addContestFailure');				
				}
				else if ($this->contest->manageAnswers($this->getAnswersFromPost()))
				{
					$this->page->assign('actionState', 'addAnswersFailure');
				}
				else 
				{
					$this->page->assign('actionState', 'addContestSuccess');
				}				
			}
		}
		
		
		/**
		 * Update an existing contest
		 */
		public function updateContestAction()
		{
			$this->validator->setPostOnly();
			
			$this->validator->setRequired(
				array('contestName', 'contestQuestion', 'contestStartDate', 'contestEndDate', 'contestActive', 'contestBonusQuestion', 'contestBonusAnswer')
			);
			
			$this->validator->setNumeric('contestBonusAnswer');
			$this->validator->setFormat(array('contestStartDate', 'contestEndDate'), '[0-9]{2}/[0-9]{2}/[0-9]{4}');

			if ($this->validator->hasErrors())
			{
				$this->page->assign('form'			, $_POST);
				$this->page->assign('answers'		, $this->getAnswersFromPost());
				$this->page->assign('errors'		, $this->validator->getErrors());
				$this->page->assign('actionState'	, 'addContestFailure');
				$this->page->assign('action'		, 'update');
			}
			else
			{
				$this->view = 'index';
				$this->contest->fromArray($_POST, 'contest');
				$this->contest->setTitle($_POST['contestName']);
				
				if (!$this->contest->updateContest())
				{
					$this->page->assign('actionState', 'updateContestFailure');				
				}
				
				else if ($this->contest->manageAnswers($this->getAnswersFromPost()))
				{
					$this->page->assign('actionState', 'addAnswersFailure');
				}/*
				else 
				{
					$this->page->assign('actionState', 'addContestSuccess');
				}*/				
			}
		}
		
		
		/**
		 * Add new answer to question/contest
		 */
		protected function addAnswerAction()
		{
			$answers 	= $this->getAnswersFromPost();
			$answerNr 	= count($answers) + 1; 

			array_push($answers, array(	'name' 		=> 'contestAnswer' . $answerNr, 
										'value' 	=> '', 
										'correct'	=> false,
			));
			
			$this->page->assign('form'		, $_POST);
			$this->page->assign('answers'	, $answers);
			
			if (isset($_POST['currentAction']))
			{
				$this->page->assign('action', $_POST['currentAction']);
			}
		}
		
		
		/**
		 * Pick another winner
		 * @param int $winnerID
		 */
		protected function pickWinnerAction($winnerID = false)
		{
			$winners	= $this->getWinnersFromPost();

			if (is_numeric($winnerID))
			{
				$winner = $this->contestsManager->getParticipantData($winnerID);
				$winners[$winner['participantID']] = $winner;		
			}
							
			$this->tmpWinners = $winners;
			sort($winners);
			$this->page->assign('winners', $winners);			
		}
		
		
		/**
		 * Delete winner from contest
		 * @param int $winnerID
		 */
		protected function deleteWinnerAction($winnerID = false)
		{
			$winners	= $this->getWinnersFromPost();

			if (is_numeric($winnerID))
			{
				unset($winners[$winnerID]);		
			}

			$this->tmpWinners = $winners;
			$this->page->assign('winners', $winners);	
		}
		
		
		/**
		 * Save winners for contest
		 */
		protected function saveWinnersAction()
		{
			if (!empty($this->contest) && is_numeric($this->contest->getContestID()))
			{
				$winners = $this->getWinnersFromPost();
				$this->contest->setWinners($winners);
			}
		}
		
		
		/**
		 * Get current questions from $_POST
		 * @return array
		 */
		protected function getAnswersFromPost()
		{
			$answers = array();
			
			foreach ($_POST as $key => $value)
			{
				if (substr($key, 0, 13) === 'contestAnswer' && $key !== 'contestAnswerCorrect')
				{
					$name = $cnt = $id = false;
					
					try 
					{
						list($name, $cnt, $id) = explode('_', $key);
					}
					catch (Exception $e)
					{
						// ignore;
					}
					
					array_push($answers, array(	'name' 		=> $key, 
												'answer' 	=> $value, 
												'correct'	=> $_POST['contestAnswerCorrect'] == $cnt,
												'answerID'	=> $id
					));
				}
			}
			
			return $answers;
		}
		
		
		/**
		 * Get winners from $_POST
		 * @return array
		 */
		protected function getWinnersFromPost()
		{
			$winners = array();
			
			foreach ($_POST as $key => $value)
			{
				if (substr($key, 0, 6) == 'winner')
				{
					$winner = $this->contestsManager->getParticipantData($value);
					$winners[$winner['participantID']] = $winner; 
				}
			}

			return $winners;
		}
		
		
		/**
		 * Forward to another page
		 * @param string $to
		 */
		protected function forward($to)
		{
			echo '<a href="$to">Click here to continue</a>';
			echo '<script>document.location="' . $to . '"</script>';
		}
		
	}
	
?>