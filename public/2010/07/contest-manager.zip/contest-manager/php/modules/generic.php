<?php
	
	/**
	 * WordPress contest plugin written for Netlog NV
	 * 
	 * @copyright 	Netlog NV (http://www.netlog.com)
	 * @author		Netlog NV  (http://www.netlog.com)
	 * @author 		Klaas Cuvelier, klaas@netlog.com (http://www.cuvedev.net)
	 * @link 		http://www.netlog.com, http://www.netlogmedia.com
	 * @version		1.0
	 * @license		GPL v2.0
	 * 
	 * Are you a talented developer or designer looking for a job? Check out http://www.netlog.jobs!
	 */

	abstract class GenericAction
	{
		protected $view = 'index';
		/**
		 * @var SubPage
		 */
		protected $page;
		
		/**
		 * @var Validator
		 */
		protected $validator; 
		
		
		
		/**
		 * Create instance
		 */
		public function __construct()
		{
			$this->page 		= new SubPage();
			$this->validator	= new Validator();
			
			if (isset($_GET['view']))
			{
				$this->view = $_GET['view'];
			}
			
			$this->doAction();
		}
		
		
		/**
		 * Default display method
		 */
		protected abstract function displayIndex();
		
		
		/**
		 * Available actions
		 */
		protected abstract function getActions();
		
		/**
		 * Check if an action is needed
		 */
		public function doAction()
		{		
			if (isset($_POST['action']) || isset($_GET['action']))
			{		
				$action = isset($_POST['action']) ? $_POST['action'] : $_GET['action'];
				$params = null;
				
				if ($action === '__button')
				{
					foreach ($_POST as $key => $value)
					{
						if (substr($key, 0, 5) === 'btn__')
						{
							list($crap, $action, $params) = explode('__', $key);
						 	break;
						}
					}
				}	
			
				$actions	= $this->getActions();
				if (is_array($actions) && in_array($action, array_keys($actions)))
				{
					$this->$actions[$action]($params);
				}
			}
		}
		
		
		/**
		 * Select the method to display
		 */
		public function display($view = null)
		{
			if (!empty($view))
			{
				$this->view = $view;
			}
			
			if (empty($this->view))
			{
				$this->view = 'index';
			}
			
			$method = 'display' . ucfirst($this->view);

			if (!method_exists($this, $method))
			{
				if ($method !== 'displayIndex')
				{
					$method = 'displayIndex';
				}
			}
			else
			{
				$this->$method();
				echo $this->page->getResult();
			}
			
			return true;
		}
		

		/**
		 * Get base url for plugin
		 * @return string
		 */
		protected function getUrl()
		{
			return '/wp-admin/admin.php?' . (isset($_GET['page']) ? 'page=' . $_GET['page'] : '');
		}	
	}
	
?>