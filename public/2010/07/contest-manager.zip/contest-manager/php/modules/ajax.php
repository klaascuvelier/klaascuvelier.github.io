<?php

	/**
	 * WordPress contest plugin written for Netlog NV
	 * 
	 * @copyright 	Netlog NV (http://www.netlog.com)
	 * @author		Netlog NV  (http://www.netlog.com)
	 * @author 		Klaas Cuvelier, klaas@netlog.com (http://www.cuvedev.net)
	 * @link 		http://www.netlog.com, http://www.netlogmedia.com
	 * @version		1.0
	 * @license		GPL v2.0
	 * 
	 * Are you a talented developer or designer looking for a job? Check out http://www.netlog.jobs!
	 */

	class AjaxAction extends GenericAction
	{	
		protected $result, $extra;
		
		/**
		 * @var ContestsManager
		 */
		protected $contestsManager;
		
		/**
		 * @var Contest
		 */
		protected $contest;
		
		
		public function __construct() 
		{
			// create contest manager
			$this->contestsManager = new ContestsManager();
			
			// check if a contest needs to be loaded
			if (isset($_GET['contestid']) && is_numeric($_GET['contestid']))
			{
				$this->contest = new Contest($_GET['contestid']);
			}
			
			parent::__construct();
		}
		
		
		/**
		 * Override default display methods
		 * @see wp-content/plugins/contest-manager/php/modules/GenericAction#display()
		 */
		public function display()
		{
			if (empty($this->view))
			{
				$this->view = 'index';
			}
			
			$method = 'display' . ucfirst($this->view);

			if (!method_exists($this, $method))
			{
				if ($method !== 'displayIndex')
				{
					$method = 'displayIndex';
				}
			}
			else
			{
				$this->$method();
				
				$reply = array();
				$reply['success'] = $this->result;
				$reply[($reply['success'] ? 'data' : 'error')] = $this->page->getResult();
			
				if (is_array($this->extra))
				{
					$reply = array_merge($this->extra, $reply);
				}
			
				die(json_encode($reply));
			}
			
			return true;
		}
		
		
		/**
		 * Return response to webpage
		 * @param boolean $success
		 * @param mixed $data
		 */
		protected function setResult($success, $extra = null)
		{
			$this->result 	= $success;
			$this->extra 	= $extra;
		} 
		
		
		
		protected function displayResults()
		{
			if (empty($this->contest) || $this->contest->getContestID() === 0)
			{
				$this->setResult(false);
			}
			else 
			{
				$participantsCount	= $this->contest->getParticipantsCount();	
				$pager				= new Pager(10, $participantsCount);

				$this->page->setFilename('admin/admin.contest.participants.list.tpl');
				$this->page->assign('participantsCount'	, $participantsCount);
				$this->page->assign('participants'		, $this->contest->getParticipants($pager->getStart(), $pager->getLimit()));
				
				$this->setResult(true, array('pagerID' => $_GET['pagerID'], 'cpn' => $pager->getPage()));
			}
		}
		
		
		protected function displayIndex() {}
		
		
		public function getActions()
		{
			return array();
		}
		
	}
	
?>