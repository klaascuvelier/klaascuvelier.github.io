<?php
  /**
  * QuickSkin Extension codesnippetend
  * required for the end of a code snippet
  *
  * Usage Example:
  * Template: Code Snippet<br />{codesnippetend:}
  *
  * @author Andy Prevost andy@codeworxtech.com
  */
  function qx_codesnippetend () {
    return '</pre>';
  }

?>
