<?php

	/**
	 * WordPress contest plugin written for Netlog NV
	 * 
	 * @copyright 	Netlog NV (http://www.netlog.com)
	 * @author		Netlog NV  (http://www.netlog.com)
	 * @author 		Klaas Cuvelier, klaas@netlog.com (http://www.cuvedev.net)
	 * @link 		http://www.netlog.com, http://www.netlogmedia.com
	 * @version		1.0
	 * @license		GPL v2.0
	 * 
	 * Are you a talented developer or designer looking for a job? Check out http://www.netlog.jobs!
	 */

	class Validator
	{
		const 	SOURCE_GETPOST 	= 1,
				SOURCE_GETONLY 	= 2,
				SOURCE_POSTONLY	= 3; 
		protected $source;
		protected $rules;
		protected $errors;
		
		

		public function __construct()
		{
			$this->setGetPost();
			$this->rules = array();
		}
		
		
		/**
		 * Set source to POST only
		 */		
		public function setPostOnly()
		{
			$this->source = self::SOURCE_POSTONLY;
		}
		
		
		/**
		 * Set source to GET only
		 */		
		public function setGetOnly()
		{
			$this->source = self::SOURCE_GETONLY;
		}
		
		
		/**
		 * Set source to GET and POST both
		 */		
		public function setGetPost()
		{
			$this->source = self::SOURCE_GETPOST;
		}
		
		
		/**
		 * Add a required field
		 * @param string $key
		 * @param string $error
		 */
		public function setRequired($key, $error = 'required')
		{
			if (is_array($key))
			{
				foreach ($key as $sub)
				{
					$this->setRequired($sub, $error);
				}
			}
			else
			{
				$this->addRule($key, 'required', $error);
			}
		}
		
		
		/**
		 * Add a numeric field
		 * @param string $key
		 * @param string $error
		 */
		public function setNumeric($key, $error = 'numeric')
		{
			if (is_array($key))
			{
				foreach ($key as $sub)
				{
					$this->setNumeric($sub, $error);
				}
			}
			else
			{
				$this->addRule($key, 'numeric', $error);
			}
		}
		
		
		/**
		 * Add a specific format for the field field
		 * @param string $key
		 * @param string $error
		 */
		public function setFormat($key, $format, $error = 'format')
		{
			if (is_array($key))
			{
				foreach ($key as $sub)
				{
					$this->setFormat($sub, $format, $error);
				}
			}
			else
			{
				$this->addRule($key, 'format', $error, $format);
			}
		}
		
		
		/**
		 * Add a specific rule for a field
		 * @param stirng $key
		 * @param string $rule
		 * @param string $error
		 * @param mixed $extra
		 */
		protected function addRule($key, $rule, $error, $extra = null)
		{
			$info = array(	'rule' 	=> $rule,
							'error'	=> $error,
							'extra'	=> $extra
			);
			
			if (!is_array($this->rules[$key]))
			{
				$this->rules[$key] = array();
			}
			
			array_push($this->rules[$key], $info);
		}
		
		
		/**
		 * Has the validator errors
		 * @return bool
		 */
		public function hasErrors()
		{
			$this->errors 	= array();
			$fields 		= $this->getSourceFields();

			foreach ($this->rules as $field => $rules)
			{
				foreach ($rules as $rule)
				{
					if ($rule['rule'] == 'required')
					{
						if (!isset($fields[$field]) || empty($fields[$field]))
						{
							$this->addError($field, $rule['error']);
						}
					}
					else if ($rule['rule'] == 'numeric')
					{
						if (!isset($fields[$field]) || !is_numeric($fields[$field]))
						{
							$this->addError($field, $rule['error']);
						}						
					}
					else if ($rule['rule'] == 'format')
					{
						$pattern = '#^' . $rule['extra'] . '$#i';
						
						if (!isset($fields[$field]) || !preg_match($pattern, $fields[$field], $var))
						{
							$this->addError($field, $rule['error']);
						}				
					}
				}
			}
			
			return count($this->errors) !== 0;
		}
		
		
		
		protected function addError($field, $error)
		{
			if (!is_array($this->errors[$field]))
			{
				$this->errors[$field] = array();
			}
			
			array_push($this->errors[$field], $error);
		}
		
		
		/**
		 * Get errors
		 */
		public function getErrors()
		{
			return $this->errors;
		}
		
		
		/**
		 * Get value for given kye 
		 * @param string $key
		 * @param mixed $default
		 */
		public function getValue($key, $default = '')
		{
			$fields = $this->getSourceFields();
			return isset($fields[$key]) ? $fields[$key] : $default;
		}
		
		
		/**
		 * Get source fields according to $this->source
		 * @return array
		 */
		protected function getSourceFields()
		{
			return $this->source == self::SOURCE_GETONLY ? $_GET 
						: ( $this->source == self::SOURCE_POSTONLY ? $_POST
							: array_merge($_GET, $_POST));	
		}
	}
	
?>