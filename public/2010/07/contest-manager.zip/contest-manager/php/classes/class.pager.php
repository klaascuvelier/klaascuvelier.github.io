<?php

	/**
	 * WordPress contest plugin written for Netlog NV
	 * 
	 * @copyright 	Netlog NV (http://www.netlog.com)
	 * @author		Netlog NV  (http://www.netlog.com)
	 * @author 		Klaas Cuvelier, klaas@netlog.com (http://www.cuvedev.net)
	 * @link 		http://www.netlog.com, http://www.netlogmedia.com
	 * @version		1.0
	 * @license		GPL v2.0
	 * 
	 * Are you a talented developer or designer looking for a job? Check out http://www.netlog.jobs!
	 */

	class Pager
	{
		protected $start, $limit, $page, $count, $url, $id;

		/**
		 * Constructor
		 * @param int $limit max items in list
		 * @param int $count set count items
		 * @param int $page set current page
		 * @param mixed $url base url for pager
		 */
		public function __construct($limit, $count = 0, $page = false, $url = false)
		{
			$this->id		= md5(microtime(true));
			
			$this->limit 	= $limit;
			$this->count	= $count;
			$this->page		= 1;
			
			if ($page !== false)
			{
				$this->page	= $page;
			}
			else if (isset($_GET['cpn']) && is_numeric($_GET['cpn']))
			{
				$this->page = (int)$_GET['cpn']; 
			}
			
			if ($url !== false)
			{
				$this->url = $url;
			}
			else
			{
				$this->url = $this->buildUrl();
			}	
		}
		
		
		/**
		 * Set #items in list
		 * @param int $count
		 */
		public function setCount($count)
		{
			$this->count = $count;
		}
		
		
		/**
		 * Set current page
		 * @param int $page
		 */
		public function setPage($page)
		{
			$this->page = $page;
		}
		
		
		/**
		 * Set base url for pageer
		 * @param mixed $url
		 */
		public function setUrl($url)
		{
			$this->url = $url;
		}
		
		
		/**
		 * Get start 
		 */
		public function getStart()
		{
			return ($this->page - 1) * $this->getLimit();
		}
		
		
		/**
		 * Get item limit
		 */
		public function getLimit()
		{
			return $this->limit;
		}
	
		
		/**
		 * Build url for pager using all $_GET
		 */
		public function buildUrl()
		{
			$params = array();
			
			foreach ($_GET as $key => $value)
			{
				if ($key !== 'cpn')
				{
					array_push($params, $key . '=' . $value);
				}
			}

			$url = '/wp-admin/admin.php?' . implode('&', $params);
			return $url;
		}
		
		
		/**
		 * Get unique identifier for this pager
		 */
		public function getPagerID()
		{
			return $this->id;	
		}
		
		
		/**
		 * Return current page;
		 * @return number
		 */
		public function getPage()
		{
			return $this->page;
		}
	
		/**
		 * Get html output for pager
		 */
		public function getHtml()
		{
			$page = new SubPage('pager.tpl');
			$page->assign('pages'	, ceil($this->count / $this->getLimit()));
			$page->assign('page'	, $this->page);
			$page->assign('url'		, $this->url);
			$page->assign('pagerID'	, $this->getPagerID());
			
			return $page->getResult();
		}
	}	
	
?>