<?php

	/**
	 * WordPress contest plugin written for Netlog NV
	 * 
	 * @copyright 	Netlog NV (http://www.netlog.com)
	 * @author		Netlog NV  (http://www.netlog.com)
	 * @author 		Klaas Cuvelier, klaas@netlog.com (http://www.cuvedev.net)
	 * @link 		http://www.netlog.com, http://www.netlogmedia.com
	 * @version		1.0
	 * @license		GPL v2.0
	 * 
	 * Are you a talented developer or designer looking for a job? Check out http://www.netlog.jobs!
	 */

	class HtmlCompiler
	{
		public function compile($page)
		{
			if (preg_match_all('/<!-- TEMPLATE wrapper(.+) -->/U', $page, $var))
			{
				$wrappers = explode('<', trim($var[1][0]));
				$wrappers = array_reverse($wrappers);

				foreach ($wrappers as $wrapper)
				{

					if (!empty($wrapper))
					{
						$tmp = new SubPage(trim($wrapper));
						$cnt = file_get_contents($tmp->getFilename());
						$cnt = str_replace('{content}', $page, $cnt);
	
						$page = $cnt;
					}
				}
				
				$page = str_replace($var[0][0], '', $page);
			}
			
			$var = null;
			
			if (preg_match_all('/<!-- TEMPLATE include="(.+)" -->/U', $page, $var))
			{
				foreach ($var[1] as $index => $include)
				{
					$include = trim($include);
	
					$tmp = new SubPage();
					if ($tmp->setFilename($include))
					{
						$cnt = file_get_contents($tmp->getFilename());
						$page = str_replace($var[0][$index], $cnt, $page);	
					}
				}
			}

			return $page;
		}
	}
	
?>