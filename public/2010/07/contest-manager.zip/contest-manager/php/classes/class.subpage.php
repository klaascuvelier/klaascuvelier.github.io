<?php

	/**
	 * WordPress contest plugin written for Netlog NV
	 * 
	 * @copyright 	Netlog NV (http://www.netlog.com)
	 * @author		Netlog NV  (http://www.netlog.com)
	 * @author 		Klaas Cuvelier, klaas@netlog.com (http://www.cuvedev.net)
	 * @link 		http://www.netlog.com, http://www.netlogmedia.com
	 * @version		1.0
	 * @license		GPL v2.0
	 * 
	 * Are you a talented developer or designer looking for a job? Check out http://www.netlog.jobs!
	 */

	DEFINE('QUICKSKIN', dirname(__FILE__) . '/../QuickSkin_v5.0/');
	require_once(QUICKSKIN . 'inc.config.php');

	class SubPage extends QuickSkin
	{
		protected $filename;
		
		
		/**
		 * Create a new SubPage instance
		 * @param string $filename, optional
		 */
		public function __construct($filename = false)
		{		
			parent::__construct();
			$this->extensions_dir	= dirname(__FILE__) . '/../qs_extensions/';
			$this->extension_prefix = 'qse_';
			
			$this->assignDefaults();
		
			if ($filename !== false)
			{
				$this->setFilename($filename);
			}
		}
	
		
		/**
		 * Set the filename of the template
		 * @param $filename
		 * @return bool
		 */
		public function setFilename($filename)
		{
			$filename = dirname(__FILE__) . '/../../tpl/' . $filename;

			if (!file_exists($filename))
			{
				return false;
			}	
			else
			{
				$this->filename = $filename;
				return true;
			} 
		}

		
		/**
		 * Output result of a template 
		 * @return void
		 */
		public function display()
		{
			if (!empty($this->filename))
			{
				$this->preParse();
				$this->output();		
			}
		}

		
		/**
		 * Get the result of the parsed templated
		 * return string
		 */
		public function getResult()
		{	
			if (!empty($this->filename))
			{
				$this->preParse();
				return $this->result();
			}
		}
	
		
		/**
		 * Method to be called before parsing the template
		 * @return void
		 */
		public function preParse()
		{
			$this->template_dir = dirname($this->filename);
			$this->set_templatefile(basename($this->filename));
			$this->temp_dir = $this->cache_dir = dirname(__FILE__) . '/../../cache/';
		}
		
		
		/**
		 * Assign default values to templates
		 */
		protected function assignDefaults()
		{
			$this->assign(
				array(
					'url' => '/wp-admin/admin.php?' . (isset($_GET['page']) ? 'page=' . $_GET['page'] : ''),
				)
			);
		}
		
	
		/**
		 * Get filename of current template
		 * @return String
		 */
		public function getFilename()
		{
			return $this->filename;
		}
	}

?>