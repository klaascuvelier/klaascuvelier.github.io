<?php

	/**
	 * WordPress contest plugin written for Netlog NV
	 * 
	 * @copyright 	Netlog NV (http://www.netlog.com)
	 * @author		Netlog NV  (http://www.netlog.com)
	 * @author 		Klaas Cuvelier, klaas@netlog.com (http://www.cuvedev.net)
	 * @link 		http://www.netlog.com, http://www.netlogmedia.com
	 * @version		1.0
	 * @license		GPL v2.0
	 * 
	 * Are you a talented developer or designer looking for a job? Check out http://www.netlog.jobs!
	 */

	class ContestManager
	{
		
		private function __construct()
		{ /* static calls only! */ }
		
		
		/**
		 * Add contest stuff to posts
		 * 
		 * @param string $post
		 * @return string
		 */
		public static function addContestToPost($post)
		{	
			if(preg_match('(\[contest_[0-9]+\])', $post, $matches))
		  	{
		    	preg_match('/[0-9]+/', $matches[0], $id);
		    	
		    	$contest		= new Contest((int)$id[0]);
		    	
		    	if (isset($_POST['action']) && $_POST['action'] == 'addVote')
		    	{
		    		$result = $contest->addVote($_POST);
		    		$contestHtml = $contest->getHtml($result);
		    	}
		    	else
		    	{	    	
		    		$contestHtml	= $contest->getHtml();
		    	}
		    	
		 
			    $post = str_replace($matches[0], $contestHtml, $post);
			    $post = str_replace('<p></p>', 'hoi', $post); 
		  }
			return $post;
		}
		
		
		/**
		 * Add menus in manage panel
		 */
		public static function addToAdminMenu()
		{
			add_menu_page('Contest Manager', 'Contests', 'manage_options', 'contest-manager.php', function() {
				$contestsAction = new ContestsAction();
				$contestsAction->display();
			});
		
			add_submenu_page('contest-manager.php', 'Contest Manager', 'Add new', 'manage_options', '', function () {
				$contestsAction = new ContestsAction();
				$contestsAction->display('add');
			});
		}
		
		
		/**
		 * Install tables
		 */
		public static function install()
		{
			global $wpdb;
		
			$wpdb->query(
				'CREATE TABLE IF NOT EXISTS ' . $wpdb->prefix . 'contests (
				  `contestID` int(10) unsigned NOT NULL AUTO_INCREMENT,
				  `title` text NOT NULL,
				  `question` text NOT NULL,
				  `startDate` datetime NOT NULL,
				  `endDate` datetime NOT NULL,
				  `active` enum("YES","NO") NOT NULL DEFAULT "YES",
				  `image` varchar(255) NOT NULL,
				  `bonusQuestion` text NOT NULL,
				  `bonusAnswer` int(10) unsigned NOT NULL,
				  `extra` text NOT NULL,
				  PRIMARY KEY (`contestID`)
				)'
			);
	
			$wpdb->query(
				'CREATE TABLE IF NOT EXISTS ' . $wpdb->prefix . 'contest_answers (
				  `answerID` int(10) unsigned NOT NULL AUTO_INCREMENT,
				  `contestID` int(10) unsigned NOT NULL,
				  `answer` text NOT NULL,
				  `votes` int(11) NOT NULL,
				  `correct` enum("YES","NO") NOT NULL DEFAULT "NO",
				  PRIMARY KEY (`answerID`),
				  UNIQUE KEY `idx_contestid_answerid` (`contestID`,`answerID`)
				)'
			);
	
			$wpdb->query(
				'CREATE TABLE IF NOT EXISTS ' . $wpdb->prefix . 'contest_participants (
				  `participantID` int(10) unsigned NOT NULL AUTO_INCREMENT,
				  `contestID` int(10) unsigned NOT NULL,
				  `answerID` int(10) unsigned NOT NULL,
				  `bonusAnswer` int(10) unsigned NOT NULL,
				  `firstName` varchar(50) NOT NULL,
				  `lastName` varchar(50) NOT NULL,
				  `company` varchar(50) NOT NULL,
				  `function` varchar(50) NOT NULL,
				  `mobile` varchar(50) NOT NULL,
				  `email` varchar(50) NOT NULL,
				  `extra` text NOT NULL,
				  `remindMe` enum("YES","NO") NOT NULL DEFAULT "YES",
				  `dateVote` datetime NOT NULL,
				  PRIMARY KEY (`participantID`),
				  UNIQUE KEY `idx_contestid_answerid_participantid` (`contestID`,`answerID`,`participantID`)
				)'
			);
	
			$wpdb->query(
				'CREATE TABLE IF NOT EXISTS ' . $wpdb->prefix . 'contest_winners (
				  `contestID` int(11) NOT NULL,
				  `participantID` int(11) NOT NULL,
				  PRIMARY KEY (`contestID`,`participantID`)
				)'
			);
			
			chmod(dirname(__FILE__) . '/../../cache/', 0777);
		}
	}
	
?>