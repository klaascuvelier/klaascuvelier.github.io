<?php
	
	/**
	 * WordPress contest plugin written for Netlog NV
	 * 
	 * @copyright 	Netlog NV (http://www.netlog.com)
	 * @author		Netlog NV  (http://www.netlog.com)
	 * @author 		Klaas Cuvelier, klaas@netlog.com (http://www.cuvedev.net)
	 * @link 		http://www.netlog.com, http://www.netlogmedia.com
	 * @version		1.0
	 * @license		GPL v2.0
	 * 
	 * Are you a talented developer or designer looking for a job? Check out http://www.netlog.jobs!
	 */

	class Contest
	{
		private $contestID, $title, $question, $startDate, $endDate, $active, $image, $bonusQuestion, $bonusAnswer;
		
		
		public function __construct($contestID = 0)
		{
			if (is_numeric($contestID) && $contestID > 0)
			{
				$this->loadContest($contestID);	
			}
		}
		
		
		/**
		 * get current contestID
		 * return int
		 */
		public function getContestID()
		{
			return is_numeric($this->contestID) ? $this->contestID : 0;
		}
		
		/**
		 * set current contestID
		 * @param int $contestID
		 */
		protected function setContestID($contestID)
		{
			$this->contestID = $contestID;
		}
		
		/**
		 * get contest title 
		 */
		public function getTitle()
		{
			return ($this->getContestID() > 0) && !empty($this->title) ? $this->title : 0;
		}
		
		/**
		 * set Title
		 * @param $title
		 */
		public function setTitle($title)
		{
			$this->title = $title;
		}
		
		/**
		 * get contest question
		 */
		public function getQuestion()
		{
			return ($this->getContestID() > 0 && !empty($this->question)) ? $this->question : '';
		}
		
		/**
		 * set question for contest
		 * @param $question
		 */
		public function setQuestion($question)
		{
			$this->question = $question;
		}
		
		/**
		 * get start date
		 */
		public function getStartDate()
		{
			return ($this->getContestID() > 0 && is_numeric($this->startDate)) ? $this->startDate : mktime();
		}
		
		/**
		 * set startdate for contest, unix timestamp!
		 * @param startDate 
		 */
		public function setStartDate($startDate)
		{
			$this->startDate = $startDate;
		}
		
		/**
		 * get end date
		 */
		public function getEndDate()
		{
			return ($this->getContestID() > 0 && is_numeric($this->endDate)) ? $this->endDate : mktime();
		}
		
		/**
		 * set enddate for contest, unix timestamp!
		 */
		public function setEndDate($endDate)
		{
			$this->endDate = $endDate;
		}
		
		/**
		 * is this contest active
		 */
		public function isActive()
		{
			return ($this->getContestID() > 0 && $this->active == 'YES') ? true : false;
		}
		
		/**
		 * activate or deactivate contest
		 * @param $active
		 */
		public function setActive($active)
		{
			$this->active = ($active === 'YES') ? true : false;
		}
		
		/**
		 * get image url
		 */
		public function getImageUrl()
		{
			return ($this->getContestID() > 0 && !empty($this->image)) ? $this->image : ''; 
		}
		
		/**
		 * set image for contest
		 * @param $image
		 */
		public function setImageUrl($image)
		{
			$this->image = $image;
		}
		
		/**
		 * get bonus question
		 */
		public function getBonusQuestion()
		{
			return $this->getContestID() > 0 && !empty($this->bonusQuestion) ? $this->bonusQuestion : '';
		}
		
		/**
		 * set new bonus question
		 * @param string $question
		 */
		public function setBonusQuestion($question)
		{
			$this->bonusQuestion($question);
		}
		
		/**
		 * get bonus answer
		 */
		public function getBonusAnswer()
		{
			return $this->getContestID() > 0 && !empty($this->bonusAnswer) ? $this->bonusAnswer : 0;
		}
		
		/**
		 * set new answer for bonus question
		 * @param string $ansower
		 */
		public function setBonusAnswer($answer)
		{
			$this->bonusQuestion($answer);
		}
		
		
		
		/**
		 * Load an existing contest
		 */
		public function loadContest($contestID)
		{
			global $wpdb, $table_prefix;
			
			$info = $wpdb->get_row(
				$wpdb->prepare('SELECT contestID, title, question, UNIX_TIMESTAMP(startDate) as startDate,
								UNIX_TIMESTAMP(endDate) as endDate, active, bonusQuestion, bonusAnswer  
								FROM ' . $wpdb->prefix . 'contests WHERE contestID = %d', $contestID),
				ARRAY_A
			);
	
			if (empty($info))
			{
				return false;
			}
			
			foreach ($info as $key => $value)
			{
				$this->$key = $value;
			}
			
			return true;
		}
		
		/**
		 * Update existing contest
		 */
		public function updateContest()
		{
			global $wpdb;
			
			if ($this->getContestID() == 0)
			{
				return false;
			}
				
			$wpdb->update($wpdb->prefix . 'contests', array(	'title'			=> $this->getTitle(), 
																	'question'		=> $this->getQuestion() ,
																	'startDate'		=> Date('Ymd', $this->getStartDate()) . '000000', 
																	'endDate'		=> Date('Ymd',$this->getEndDate()) . '000000', 
																	'active'		=> $this->isActive() ? 'YES' : 'NO', 
																	'image'			=> $this->getImageUrl(), 
																	'bonusQuestion'	=> $this->getBonusQuestion(),
																	'bonusAnswer'	=> $this->getBonusAnswer(),
																	'extra'		=> '',
															),
															array('contestID' => $this->getContestID()),
															array('%s', '%s', '%d', '%d', '%s', '%s', '%s', '%s', '%s'),
															array('%d')
			);
			
			return true;
		}
	
		/*
		 * Create new contest
		 */
		public function createContest()
		{
			global $wpdb;
			
			$this->contestID = 999; // <- whoops crappy fix goes here ...
	
			$wpdb->insert($wpdb->prefix . 'contests', array(	'title'			=> $this->getTitle(), 
																	'question'		=> $this->getQuestion(), 
																	'startDate'		=> $this->getStartDate(), 
																	'endDate'		=> $this->getEndDate(), 
																	'bonusQuestion'	=> $this->getBonusQuestion(),
																	'bonusAnswer'	=> $this->getBonusAnswer(),
																	'active'		=> $this->isActive() ? 'YES' : 'NO', 
																	'image'			=> $this->getImageUrl(),
																	'extra'			=> '',
															), 
															array('%s', '%s', '%d', '%d', '%s', '%d', '%s', '%s', '%s')
			);
															
			$this->setContestID($wpdb->insert_id);
			
			return true;
		}
		
		
		/**
		 * get html output for this competition
		 */
		public function getHtml($success = null)
		{
			$success = ($success !== false && $success !== true) ? '' : ($success === true ? 'voteSuccess' : 'voteFailure');

			$page = new SubPage();
			if ($this->isOpen())
			{
				$page->setFilename('contest.one.tpl');
				$page->assign('actionState'	, $success);
				$page->assign('form'		, $_POST);
			}
			else
			{
				$page->setFilename('contest.one.closed.tpl');
				$page->assign('winners'		, $this->getWinners());
			}

			$page->assign('contest'	, $this->toArray());
			$page->assign('answers'	, $this->getAnswers());

			$result = '<div class="contest">' . $page->getResult() . '</div>' . 
						'<br style="clear: both;" />';
			
			return $result;
		}
		
		
		/**
		 * @todo @klaas: fix
		 * get answers for this contest
		 */
		public function getAnswers()
		{
			global $wpdb;
			
			$results = $wpdb->get_results('SELECT * FROM ' . $wpdb->prefix . 'contest_answers nca 
											WHERE contestID = ' . $this->getContestID() . ' 
											ORDER BY answerID ASC', ARRAY_A);
		
			foreach ($results as $index => $result)
			{
				$results[$index]['correct'] = ($result['correct'] == 'YES');
			}
			
			return $results;
		}
		
		
		/**
		 * @todo @klaas: fix
		 * get participants for this contest
		 */
		public function getParticipants($start = 0, $limit = 10)
		{
			global $wpdb;
			
			$results = $wpdb->get_results('SELECT ncp.*, CASE WHEN ISNULL(ncw.participantID) THEN "NO" ELSE "YES" END as winner 
											FROM ' . $wpdb->prefix . 'contest_participants ncp
											LEFT JOIN ' . $wpdb->prefix . 'contest_winners ncw 
												ON ncp.participantID = ncw.participantID
											WHERE ncp.contestID = ' . $this->getContestID() . ' 
											ORDER BY ncp.company ASC, ncp.lastName ASC, ncp.firstname ASC 
											LIMIT ' . $start . ', ' . $limit, ARRAY_A);	
			
			return $results;
		}
		
		
		/**
		 * get possible winners for this contest
		 */
		public function getPossibleWinners()
		{
			global $wpdb;
			
			$results = $wpdb->get_results('SELECT ncp.*, GREATEST(nc.bonusAnswer, ncp.bonusAnswer) - LEAST(nc.bonusAnswer, ncp.bonusAnswer) as diffBonus 
											FROM ' . $wpdb->prefix . 'contest_participants ncp
											JOIN ' . $wpdb->prefix . 'contest_answers nca 
												ON ncp.answerID = nca.answerID
											JOIN ' . $wpdb->prefix . 'contests nc
												ON ncp.contestID = nc.contestID
											WHERE ncp.contestID = ' . $this->getContestID() . ' AND nca.correct = "YES"
											ORDER BY diffbonus ASC, ncp.company ASC, ncp.lastName ASC, ncp.firstname ASC', 
						ARRAY_A);	
			
			return $results;
		}
	
		
		/**
		 * @todo @klaas: fix
		 * get participants count for this contest
		 */
		public function getParticipantsCount()
		{
			global $wpdb;
			
			$count = $wpdb->get_var('SELECT count(*) FROM ' . $wpdb->prefix . 'contest_participants WHERE contestID = ' . $this->getContestID());
			return $count;
		}
		
		
		/**
		 * @todo @klaas: fix
		 * @param $data
		 */
		public function addVote($data)
		{
			if (
					!isset($data['contestID']) 		|| !is_numeric($data['contestID'])
				||	!isset($data['answer']) 		|| !is_numeric($data['answer'])
				||	!isset($data['bonusAnswer']) 	|| !is_numeric($data['bonusAnswer'])
				||	!isset($data['firstName']) 		|| empty($data['firstName'])
				||	!isset($data['lastName']) 		|| empty($data['lastName'])
				||	!isset($data['company']) 		|| empty($data['company'])
				||	!isset($data['function']) 		|| empty($data['function'])
				||	!isset($data['mobileNumber']) 	|| empty($data['mobileNumber'])
				||	!isset($data['email']) 			|| empty($data['email'])
			)
			{
				return false;
			}
	
			global $wpdb;
			
			$extra = array();
			
			if (isset($data['extraThursday']))
			{
				array_push($extra, 'thursday');
			}
			
			if (isset($data['extraFriday']))
			{
				array_push($extra, 'friday');
			}
			
			if (isset($data['extraSunday']))
			{
				array_push($extra, 'sunday');
			}
			
			if (isset($data['extra4day']))
			{
				array_push($extra, '4 days combi');
			}
			
			$extra = implode(', ', $extra);
			
			$wpdb->insert($wpdb->prefix . 'contest_participants', 
							array(	'contestID'		=> $this->getContestID(),
									'answerID'		=> $data['answer'],
									'bonusAnswer'	=> $data['bonusAnswer'],
									'firstName'		=> $data['firstName'],
									'lastName'		=> $data['lastName'],
									'company'		=> $data['company'],
									'function'		=> $data['function'],
									'mobile'		=> $data['mobileNumber'],
									'email'			=> $data['email'],
									'extra'			=> $extra,
									'remindMe'		=> $data['remindMe'] ? 'YES' : 'NO',
									'dateVote'		=> date('YmdHis'),
							), 
							array('%d','%d', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')
							);
			
			//setcookie('netlog-contest-' . $this->getContestID(), 'voted', time()+(3600*24*356));				
			
			return true;
		}
		
		/**
		 * Change to array
		 * @return mixed
		 */
		public function toArray($prefix = '')
		{
			$array = array();
			
			foreach ($this as $key => $value)
			{
				$arrayKey 			= empty($prefix) ? $key : $prefix . ucfirst($key);
				$array[$arrayKey] 	= $value;
			}
			
			$array['open'] = $this->isOpen();
			
			return $array;
		}
		
		
		/**
		 * Fill object from array
		 * @param array $array
		 * @param string $prefix, optional
		 */
		public function fromArray($array, $prefix = '')
		{
			if (!is_array($array))
			{
				return false;
			}
			
			foreach ($this as $key => $value)
			{
				if (!empty($prefix))
				{
					$arrayKey = $prefix . ucfirst($key);
				}	
				
				if (isset($array[$arrayKey]))
				{
					$value = $array[$arrayKey];
					
					if ($key == 'startDate' || $key == 'endDate')
					{
						if (strpos($value, '/') > 0)
						{
							list($d, $m, $y)	= explode('/', $value);
							$value 				= strtotime($y . $m . $d . '000000');
						}	
					}
					
					$this->$key = $value;
				}
			}
			
			return true;
		}
		
		
		/**
		 * Manage questions from contest
		 * @param aary $answers
		 */
		public function manageAnswers($answers)
		{
			global $wpdb;
	
			foreach ($answers as $answer) 
			{
				$answer['answer'] = trim($answer['answer']);
				
				if (is_numeric($answer['answerID']) && $answer['answerID'] > 0 && empty($answer['answer']) && $answer['correct'] === false)
				{
					// delete exsisting
					$wpdb->query('DELETE FROM ' . $wpdb->prefix . 'contest_answers WHERE answerID = ' . $answer['answerID']);
				}
				else if(is_numeric($answer['answerID']) && $answer['answerID'] > 0 && !empty($answer['answer']))
				{
					$wpdb->update($wpdb->prefix . 'contest_answers',
						array(	'answer'	=> $answer['answer'],
								'correct'	=> $answer['correct'] === true ? 'YES' : 'NO'),
						array(	'answerID'	=> $answer['answerID']),
						array(	'%s', '%s'),
						array(	'%d')
					);
				}
				else if(empty($answer['answerID'])  && !empty($answer['answer']))
				{
					// add new
					$wpdb->insert($wpdb->prefix . 'contest_answers', 
								array(	'contestID'	=> $this->getContestID(),
										'answer'	=> $answer['answer'],
										'correct'	=> $answer['correct'] === true ? 'YES' : 'NO' ),
								array('%d', '%s', '%s')
					);
				}
				// else: ignore, empty shit
			}
			
			return true;
		}
		
		
		/**
		 * Set winners for this contest
		 * @param array $winners
		 * @return bool
		 */
		public function setWinners($winners)
		{
			if (!is_array($winners))
			{
				return false;
			}
			
			global $wpdb;
			
			$wpdb->query('DELETE FROM ' . $wpdb->prefix . 'contest_winners WHERE contestID = ' . $this->getContestID());
			
			foreach ($winners as $winner)
			{
				$wpdb->insert($wpdb->prefix . 'contest_winners', 
	 							array(	'contestID'			=> $this->getContestID(),
										'participantID'		=> $winner['participantID'],
								), 
								array('%d', '%d')
				);
			}
			
			return true;
		}
		
		
		/**
		 * Get winners for this contest
		 * @return array
		 */
		public function getWinners()
		{
			global $wpdb;
			
			$results = $wpdb->get_results('SELECT ncp.* 
											FROM ' . $wpdb->prefix . 'contest_winners ncw
											JOIN ' . $wpdb->prefix . 'contest_participants ncp 
												ON ncp.participantID = ncw.participantID
											WHERE ncw.contestID = ' . $this->getContestID(), 
						ARRAY_A);	
		
			return $results;
		}
		
		
		/**
		 * Is active and date is running
		 */
		public function isOpen()
		{
			return (mktime() > $this->getStartDate() && mktime() < $this->getEndDate() && $this->isActive());
		}
		
	}
	
?>