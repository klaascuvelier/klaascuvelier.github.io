<?php

	/**
	 * WordPress contest plugin written for Netlog NV
	 * 
	 * @copyright 	Netlog NV (http://www.netlog.com)
	 * @author		Netlog NV  (http://www.netlog.com)
	 * @author 		Klaas Cuvelier, klaas@netlog.com (http://www.cuvedev.net)
	 * @link 		http://www.netlog.com, http://www.netlogmedia.com
	 * @version		1.0
	 * @license		GPL v2.0
	 * 
	 * Are you a talented developer or designer looking for a job? Check out http://www.netlog.jobs!
	 */
	
	class ContestsManager
	{		
		/**
		 * Get all existing contests
		 * @param mixed $finished, optional, does contest need to be finished
		 * @param int $start
		 * @param int $count
		 * @return array
		 */	
		public function getAllContests($finished = null, $start = false, $count = 30)
		{
			global $wpdb;
			
			$limit = '';
			if ($start !== false || $count !== false)
			{
				$limit = ' LIMIT ' . ($start !== false ? (int)$start : '0') . ', ' . ($count!== false ? (int)$count : 30);
			}
			
			if ($finished === false)
			{
				$finished = 'WHERE endDate > NOW() AND active = "YES"';
			}
			else if ($finished === true)
			{
			 	$finished = 'WHERE endDate <= NOW() OR active = "NO"';
			}
			else
			{
				$finished = '';
			}
			
			$results = $wpdb->get_results(
				$wpdb->prepare('SELECT contestID, title, question, UNIX_TIMESTAMP(startDate) as startDate,
								UNIX_TIMESTAMP(endDate) as endDate, 0 as players, active FROM ' . $wpdb->prefix . 'contests 
								' . $finished . '   
								ORDER BY contestID ASC' . $limit ),
				ARRAY_A
			);
			
			return $results;			
		}
		
		
		/**
		 * Get data for graphical presentation
		 * @param int $contestID
		 */
		public function getVoteData($contestID)
		{
			global $wpdb;

			$contestID = (int)$contestID;
			
			$results = $wpdb->get_results(
				$wpdb->prepare('SELECT DISTINCT DATE(dateVote) as `date`, 
								(SELECT count(*) FROM ' . $wpdb->prefix . 'contest_participants
									WHERE contestID = ' . $contestID . ' AND DATE(dateVote) = `date`) as votes
								FROM ' . $wpdb->prefix . 'contest_participants WHERE contestID = ' . $contestID . ' 
								ORDER BY dateVote ASC')	,
				ARRAY_A
			);
			
			return $results;
		}
		
		
		/**
		 * Get info for participant
		 * @param int $participant
		 * @return array
		 */
		public function getParticipantData($participantID)
		{
			global $wpdb;

			$participantID = (int)$participantID;
			
			$result = $wpdb->get_row(
				$wpdb->prepare('SELECT * FROM ' . $wpdb->prefix . 'contest_participants 
								WHERE participantID = ' . $participantID),
				ARRAY_A
			);
			
			return $result;
		}
	}

?>