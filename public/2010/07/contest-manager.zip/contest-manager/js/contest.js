/**
 * WordPress contest plugin written for Netlog NV
 * 
 * @copyright 	Netlog NV (http://www.netlog.com)
 * @author		Netlog NV  (http://www.netlog.com)
 * @author 		Klaas Cuvelier, klaas@netlog.com (http://www.cuvedev.net)
 * @link 		http://www.netlog.com, http://www.netlogmedia.com
 * @version		1.0
 * @license		GPL v2.0
 * 
 * Are you a talented developer or designer looking for a job? Check out http://www.netlog.jobs!
 */

jQuery(document).ready(function () {
	observeAnswerButton();
	observePickWinners();

	try 
	{
		jQuery('.pickDate').datepicker({ dateFormat: 'dd/mm/yy' });
	}
	catch(e) {} 
});



function observeAnswerButton() 
{
	jQuery('#addAnswer').click(function () {
		var answerTable = jQuery('#contestAnswers');
		var nextClass	= answerTable.find('tr:last').hasClass('odd') ? 'even' : 'odd';
		var cnt			= answerTable.find('tr').length - 1;
		
		answerTable.append('<tr class="' + nextClass + '">' +
							'<td><input type="radio" class="radio" name="contestAnswerCorrect" id="contestAnswerCorrect' + cnt + '" value="' + cnt + '" /></td>' +
							'<td><input type="text" name="contestAnswer' + cnt + '" id="contestAnswer_' + cnt + '_0" value="" class="text required" /></td>' +
		 				'</tr>');
		 				
		 return false;
	});
}


function observePickWinners()
{
	jQuery('input.pickWinner').live('click', function () {
		var info 	= jQuery(this).attr('name').split('__');
		var prnt 	= jQuery(this).parents('tr');
		var pid		= info[2];
		var fname 	= prnt.find('td.firstname').html();
		var lname 	= prnt.find('td.lastname').html();
		var cmpny 	= prnt.find('td.company').html();

		jQuery('ul#winners').append('<li>' +
										'<input type="submit" class="deleteWinner" value="' + fname + ' ' + lname + ' (' + cmpny + ')" name="btn__deleteWinner__' + pid + '" />' +
										'<input type="hidden" value="' + pid + '" name="winner__' + pid + '" />' + 
									'</li>');
		prnt.addClass('isWinner');
		
		updateClassesFrom(prnt.prevAll(':not(.isWinner):first'));

		return false;
	});
	
	jQuery('input.deleteWinner').live('click', function () {
		var info = jQuery(this).attr('name').split('__');
		var curr = jQuery('tr#participant_' + info[2])
		var even = false;
		
		curr.removeClass('isWinner');
		if (curr.prevAll(':not(.isWinner):first').hasClass('even'))
		{
			curr.removeClass('even').addClass('odd');
			even = true;
		}
		else
		{
			curr.removeClass('odd').addClass('even');
			even = false;
		}
		
		updateClassesFrom(curr);
		
		jQuery(this).parents('li').remove();
		
		return false;
	});
}



function updateClassesFrom(from)
{
	var even = from.hasClass('odd');
	from.nextAll(':not(.isWinner)').each( function (i) {
		if (even)
		{
			jQuery(this).removeClass('odd').addClass('even');
		}
		else
		{
			jQuery(this).removeClass('even').addClass('odd');
		}	
		even = !even;
	});
}