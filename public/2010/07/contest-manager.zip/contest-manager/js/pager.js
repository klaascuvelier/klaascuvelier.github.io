/**
 * WordPress contest plugin written for Netlog NV
 * 
 * @copyright 	Netlog NV (http://www.netlog.com)
 * @author		Netlog NV  (http://www.netlog.com)
 * @author 		Klaas Cuvelier, klaas@netlog.com (http://www.cuvedev.net)
 * @link 		http://www.netlog.com, http://www.netlogmedia.com
 * @version		1.0
 * @license		GPL v2.0
 * 
 * Are you a talented developer or designer looking for a job? Check out http://www.netlog.jobs!
 */

jQuery(document).ready(function($) {
	makeAjaxPagers();
});

function makeAjaxPagers()
{
	var pagers = jQuery('ul.pager');
	
	pagers.each(function (i) {
		var pager 	= jQuery(this);
		var pagerID = pager.attr('id').split('_')[1];
		var pages	= pager.find('li > a');
		
		pages.each(function (j) {
			var page = jQuery(this);
			page.click(function (evt) {
				var page 	= jQuery(this);
				var pager	= page.parent('ul.pager');
				if (pager.hasClass('locked'))
				{
					return false;
				}
				
				pager.addClass('locked');
				
				var params = page.attr('href').split('?')[1].split('&');

				var data = {
					pagerID: pagerID,
					action:  'contest-manager-ajax'
				};
				
				jQuery(params).each(function (i) {
					var spl = this.split('=');
					data[spl[0]] = spl[1];
				});				
				
				jQuery.getJSON(ajaxurl, data, function(response) {
					if (response.success)
					{
						var placeholder = jQuery('#ajax_' + response.pagerID);
						if (placeholder)
						{
							placeholder.fadeOut('fast', function() {
								placeholder.html(response.data).fadeIn()
							});
						}
						
						var pager = jQuery('ul#pager_' + response.pagerID);						
						pager.find('li > a.current').removeClass('current');
						pager.find('li > a.page_' + response.cpn).addClass('current');
						pager.removeClass('locked');						
					}
				});
				
				return false;
			});
		});
	});
	
}


function doAjaxPagerRequest(pagerID, url)
{
	
}