<?php

	/*
	Plugin Name: 	Contest Manager
	Description: 	Contest Manager plugin. Add and manage contests on your WordPress website with this plugin. Create a contest, add multiple answers and (optionally) a bonusquestion. And when your contest is finished, manually select the winners. 
	Version: 		1.0
	Author: 		Netlog NV
	Author URI: 	http://www.cuvedev.net/contest-plugin
	License: 		GPL2
	*/

	/**
	 * WordPress contest plugin written for Netlog NV
	 * 
	 * @copyright 	Netlog NV (http://www.netlog.com)
	 * @author		Netlog NV  (http://www.netlog.com)
	 * @author 		Klaas Cuvelier, klaas@netlog.com (http://www.cuvedev.net)
	 * @link 		http://www.netlog.com, http://www.netlogmedia.com
	 * @version		1.0
	 * @license		GPL v2.0
	 * 
	 * Are you a talented developer or designer looking for a job? Check out http://www.netlog.jobs!
	 */



/**
 * WordPress Hooks
 */
	// activation of the plugin
	register_activation_hook(__FILE__, 'install' );
	
	
	// find contest in post
	add_filter('the_content', function ($post) {
		return ContestManager::addContestToPost($post);
	});


	// javascript for main blog
	/*
	add_action('wp_head', function () {
		return ContestController::addHeadData();
	});
	*/
	
	 // add the management page to the admin nav bar
	add_action('admin_menu', function () {
		return ContestManager::addToAdminMenu();
	});
	
	// ajax actions
	add_action('wp_ajax_contest-manager-ajax', function() {	
		$ajax = new AjaxAction();
		$ajax->display();
		exit;
	});
	
	// install this plugin
	function install() 
	{
		ContestManager::install();
	}
	
	
		/**
	 * Autoload function
	 * @param mixed $class
	 * @return bool;
	 */
	function __autoload($class)
	{
		// check if it's a wordpress class
		if (substr(strtolower($class), 0, 3) === 'wp_')
		{
			return true;
		}
		
		// otherwise, try to load it via this function
		try 
		{
			$path = '';
			
			if (substr(strtolower($class), 0, 9) === 'quickskin')
			{
				// quickskin classes
				$path = dirname(__FILE__) . '/php/QuickSkin_v5.0/_lib/class.' . strtolower($class) . '.php';	
			}
			else if (substr(strtolower($class), strlen($class) - 6) === 'action') 
			{
				// plugin modules
				$path = dirname(__FILE__) . '/php/modules/' . strtolower(substr($class, 0, strlen($class) - 6)) . '.php';
			}
			else 
			{
				// plugin classes
				$path = dirname(__FILE__) . '/php/classes/class.' . strtolower($class) . '.php';
			}
			
			if (!empty($path) && file_exists($path))
			{
				require_once($path);
				return true;
			}
			
			return false;
		}
		catch(Exception $e)
		{
			return false;
		}
	}
	
?>
